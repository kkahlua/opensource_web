var map_count = 1; // 몇번째 맵이 클릭 됬는지

var map = new Image(); // 맵 이미지
map.src = "image/map.png";

		// 맵 그리기
		class Mapdr{
			draw(context){
					context.drawImage(map, 340, 100, 815, 587); // 그리기
			}
			
			clickMap1(xmouse,ymouse){
				if(xmouse > 457 && xmouse < 496 && ymouse > 367 && ymouse < 403){
					map_do = 0;
					map_count = 1;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap2(xmouse,ymouse){
				if(xmouse > 694 && xmouse < 728 && ymouse > 308 && ymouse < 343){
					map_do = 0;
					map_count = 2;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap3(xmouse,ymouse){
				if(xmouse > 811 && xmouse < 848 && ymouse > 191 && ymouse < 228){
					map_do = 0;
					map_count = 3;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap4(xmouse,ymouse){
				if(xmouse > 812 && xmouse < 848 && ymouse > 428 && ymouse < 462){
					map_do = 0;
					map_count = 4;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap5(xmouse,ymouse){
				if(xmouse > 987 && xmouse < 1023 && ymouse > 427 && ymouse < 462){
					map_do = 0;
					map_count = 5;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap6(xmouse,ymouse){
				if(xmouse > 988 && xmouse < 1023 && ymouse > 545 && ymouse < 577){
					map_do = 0;
					map_count = 6;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap7(xmouse,ymouse){
				if(xmouse > 753 && xmouse < 787 && ymouse > 544 && ymouse < 578){
					map_do = 0;
					map_count = 7;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
		}
			
		let mapdr = new Mapdr();
		
		function GoMap() {
			clearInterval(intervalId);
  		  mapdr.draw(context);
  		  if(map_count == 1)
  			  context.drawImage(myair, 460, 370, 30, 30);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		  else if(map_count == 2)
  			  context.drawImage(myair, 697, 311, 30, 30);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		  else if(map_count == 3)
  			  context.drawImage(myair, 814, 194, 30, 30);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		  else if(map_count == 4)
  			  context.drawImage(myair, 815, 431, 30, 30);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		else if(map_count == 5)
			  context.drawImage(myair, 990, 430, 30, 30);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		else if(map_count == 6)
			  context.drawImage(myair, 991, 548, 30, 30);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		else
			  context.drawImage(myair, 756, 547, 30, 30);     // 비행기가 움직이는 대로
																// 다시 그려줌
}