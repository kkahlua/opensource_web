// 튕기는 철 블럭 지정
var iron = new Image();
iron.src = "image/iron.png";
var ironList = [];

//튕기는 철1 블럭 지정
var iron1 = new Image();
iron1.src = "image/iron1.png";
var iron1List = [];

//튕기는 철2 블럭 지정
var iron2 = new Image();
iron2.src = "image/iron2.png";
var iron2List = [];

//튕기는 철3 블럭 지정
var iron3 = new Image();
iron3.src = "image/iron3.png";
var iron3List = [];

//튕기는 철4 블럭 지정
var iron4 = new Image();
iron4.src = "image/iron4.png";
var iron4List = [];

// 튕기는 블럭 만들기
function makeiron(objx,objy) {
    var obj = {};
    obj.x = objx;
    obj.y = objy;
    ironList.push(obj);
  }

//튕기는 블럭1 만들기
function makeiron1(objx,objy) {
    var obj = {};
    obj.x = objx;
    obj.y = objy;
    iron1List.push(obj);
  }

//튕기는 블럭2 만들기
function makeiron2(objx,objy) {
    var obj = {};
    obj.x = objx;
    obj.y = objy;
    iron2List.push(obj);
  }

//튕기는 블럭3 만들기
function makeiron3(objx,objy) {
    var obj = {};
    obj.x = objx;
    obj.y = objy;
    iron3List.push(obj);
  }

//튕기는 블럭4 만들기
function makeiron4(objx,objy) {
    var obj = {};
    obj.x = objx;
    obj.y = objy;
    iron4List.push(obj);
  }

//function makeAlliron(){
//  	 makeiron(300,h-groundsizeY-200);
//  	 
//  	makeiron1(500,h-groundsizeY-200);
//  	makeiron2(700,h-groundsizeY-200);
//  	makeiron3(900,h-groundsizeY-200);
//  	makeiron4(1100,h-groundsizeY-200);
//}

function drawiron(){
    for(var i =0;i<ironList.length;i++)
    {
      var tmp = ironList[i];
      
      context.drawImage(iron,tmp.x,tmp.y,groundsizeX,groundsizeY);
    }
    for(var i =0;i<iron1List.length;i++)
    {
      var tmp = iron1List[i];
      
      context.drawImage(iron1,tmp.x,tmp.y,groundsizeX,groundsizeY);
    }
    for(var i =0;i<iron2List.length;i++)
    {
      var tmp = iron2List[i];
      
      context.drawImage(iron2,tmp.x,tmp.y,groundsizeX,groundsizeY);
    }
    for(var i =0;i<iron3List.length;i++)
    {
      var tmp = iron3List[i];
      
      context.drawImage(iron3,tmp.x,tmp.y,groundsizeX,groundsizeY);
    }
    for(var i =0;i<iron4List.length;i++)
    {
      var tmp = iron4List[i];
      
      context.drawImage(iron4,tmp.x,tmp.y,groundsizeX,groundsizeY);
    }
  }