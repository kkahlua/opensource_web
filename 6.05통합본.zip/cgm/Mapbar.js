var map_count = 1; // 몇번째 맵이 클릭 됬는지

var map = new Image(); // 맵 이미지
map.src = "image/map.png";
var pix = new Image(); // 테스트 이미지
pix.src = "image/golem/pix.png";
var pixsize=80;

		// 맵 그리기
		class Mapdr{
			draw(context){
				context.fillStyle = "#a6e1f5";
                context.fillRect(0, 0, 1500, 800);
					context.drawImage(map, 340, 100, 815, 587); // 그리기
			}
			
			clickMap1(xmouse,ymouse){
				if(xmouse > 457 && xmouse < 496 && ymouse > 367 && ymouse < 403){
					map_do = 0;
					map_count = 1;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap2(xmouse,ymouse){
				if(xmouse > 694 && xmouse < 728 && ymouse > 308 && ymouse < 343){
					map_do = 0;
					map_count = 2;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap3(xmouse,ymouse){
				if(xmouse > 811 && xmouse < 848 && ymouse > 191 && ymouse < 228){
					map_do = 0;
					map_count = 3;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap4(xmouse,ymouse){
				if(xmouse > 812 && xmouse < 848 && ymouse > 428 && ymouse < 462){
					map_do = 0;
					map_count = 4;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap5(xmouse,ymouse){
				if(xmouse > 987 && xmouse < 1023 && ymouse > 427 && ymouse < 462){
					map_do = 0;
					map_count = 5;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap6(xmouse,ymouse){
				if(xmouse > 988 && xmouse < 1023 && ymouse > 545 && ymouse < 577){
					map_do = 0;
					map_count = 6;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap7(xmouse,ymouse){
				if(xmouse > 753 && xmouse < 787 && ymouse > 544 && ymouse < 578){
					map_do = 0;
					map_count = 7;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
		}
			
		let mapdr = new Mapdr();
		
		function GoMap() {
			clearInterval(intervalId);
  		  mapdr.draw(context);
  		  if(map_count == 1)
  			  context.drawImage(pix, 460-pixsize/4, 370-pixsize*2/3, pixsize, pixsize);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		  else if(map_count == 2)
  			  context.drawImage(pix, 697-pixsize/4, 311-pixsize*2/3, pixsize, pixsize);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		  else if(map_count == 3)
  			  context.drawImage(pix, 814-pixsize/4, 194-pixsize*2/3, pixsize, pixsize);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		  else if(map_count == 4)
  			  context.drawImage(pix, 815-pixsize/4, 431-pixsize*2/3, pixsize, pixsize);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		else if(map_count == 5)
			  context.drawImage(pix, 990-pixsize/4, 430-pixsize*2/3, pixsize, pixsize);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		else if(map_count == 6)
			  context.drawImage(pix, 991-pixsize/4, 548-pixsize*2/3, pixsize, pixsize);     // 비행기가 움직이는 대로
																// 다시 그려줌
  		else
			  context.drawImage(pix, 756-pixsize/4, 547-pixsize*2/3, pixsize, pixsize);     // 비행기가 움직이는 대로
																// 다시 그려줌
}