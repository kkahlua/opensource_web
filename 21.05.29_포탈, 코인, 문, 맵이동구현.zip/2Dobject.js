//지형
var ground = new Image();
ground.src = "image/ground.png";
var groundsizeX = 50;
var groundsizeY = 50;
var groundList = [];
//문
var door = new Image();
door.src = "image/door.png";
var doorsizeX = 100;
var doorsizeY = 100;
var doorList = [];
//잠긴문
var lock = new Image();
lock.src = "image/lock.png";
var locksizeX = 100;
var locksizeY = 100;
var lockList = [];
//엘리베이터
var enemy1 = new Image();
enemy1.src = "image/water1.png";
var black0sizeX=150;
var black0sizeY=50;


function drawGround(){
	for(var i =0;i<groundList.length;i++)
	{
		var tmp = groundList[i];
		context.drawImage(ground,tmp.x,tmp.y,groundsizeX,groundsizeY);
	}
}
function drawDoor(){
	for(var i =0;i<doorList.length;i++)
	{
		var tmp = doorList[i];
		context.drawImage(door,tmp.x,tmp.y,doorsizeX,doorsizeY);
	}
}
function drawLock(){
	for(var i =0;i<lockList.length;i++)
	{
		var tmp = lockList[i];
		context.drawImage(lock,tmp.x,tmp.y,locksizeX,locksizeY);
	}
}
function drawEnemy() {
	for (var i = 0; i < enemyList.length; i++) {
		var tmp = enemyList[i];
		context.drawImage(enemy1, tmp.x, tmp.y, black0sizeX, black0sizeY);
	}

}
function makeGround(objx,objy) {
	var obj = {};
	obj.x = objx;
	obj.y = objy;
	groundList.push(obj);
}
function makeLock(objx,objy) {
	var obj = {};
	obj.x = objx;
	obj.y = objy;
	lockList.push(obj);
}
function makeDoor(objx,objy) {
	var obj = {};
	obj.x = objx;
	obj.y = objy;
	doorList.push(obj);
}
function makeEnemy(objx,objy) {


	var obj = {};
            // 위치 설정
            obj.x = objx;
            obj.y = objy;

            enemyList.push(obj);

        }
        function makeAllDoor()
        {
        	makeDoor(1400,100);
        }
        function makeAllLock()
        {
        	makeLock(1400,100);
        }
        function makeAllEnemy() {
        	makeEnemy(675,h-groundsizeY);
        	makeEnemy(675,450);
        }
        function makeAllGround(){
        	makeGround(0,h-groundsizeY);
        	makeGround(50,h-groundsizeY);
        	makeGround(100,h-groundsizeY);
        	makeGround(100,600);
        	makeGround(150,h-groundsizeY);
        	makeGround(200,h-groundsizeY);
        	makeGround(250,h-groundsizeY);
        	makeGround(300,h-groundsizeY);
        	makeGround(350,h-groundsizeY);
        	makeGround(400,h-groundsizeY);
        	makeGround(450,h-groundsizeY);
        	makeGround(500,h-groundsizeY);   
        	makeGround(550,h-groundsizeY);  
        	makeGround(600,h-groundsizeY);
        	makeGround(650,h-groundsizeY);
        	makeGround(620,h-groundsizeY-120);
        	makeGround(700,h-groundsizeY);
        	makeGround(750,h-groundsizeY);
        	makeGround(800,h-groundsizeY);
        	makeGround(850,h-groundsizeY);
        	makeGround(900,h-groundsizeY);
        	makeGround(950,h-groundsizeY);
        	makeGround(1000,h-groundsizeY);
        	makeGround(1050,h-groundsizeY);
        	makeGround(1100,h-groundsizeY);
        	makeGround(1150,h-groundsizeY);
        	makeGround(1200,h-groundsizeY);
        	makeGround(1250,h-groundsizeY);
        	makeGround(1300,h-groundsizeY);
        	makeGround(1350,h-groundsizeY);
        	makeGround(1400,h-groundsizeY);
        	makeGround(1450,h-groundsizeY);                    
        	makeGround(750,450);
        	makeGround(800,450);
        	makeGround(850,450);
        	makeGround(900,450);
        	makeGround(950,450);
        	makeGround(1000,450);
        	makeGround(850,450);
        	makeGround(900,450);
        	makeGround(950,450);
        	makeGround(1000,450);
        	makeGround(1050,450);
        	makeGround(1100,450);
        	makeGround(1150,450);
        	makeGround(1200,450);
        	makeGround(1250,450);
        	makeGround(1300,450);
        	makeGround(1350,450);
        	makeGround(1400,450);
        	makeGround(1450,450);
        	makeGround(1350,250);
        	makeGround(1400,175);
        	makeGround(1450,175);

        }