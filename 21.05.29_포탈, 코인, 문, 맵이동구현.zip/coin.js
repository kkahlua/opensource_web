var coin = new Image();
coin.src = "image/coin.png";
var _frame=0;
var _maxFrame =6;

function drawCoinM1() {
        
                context.drawImage(coin, _frame %3, Math.floor(_frame / 3) * 3000,
                               2400, 2400, 1400, 300, 100, 100);
                _frame = (_frame + 0.1) % _maxFrame;            
      }