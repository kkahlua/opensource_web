var missilebutton = new Image();
missilebutton.src = "image/missilebutton.png";
var missilebuttonList = [];

var check = 0;

function makemissilebutton(objx, objy) {// 버튼업
	var obj = {};
	// 위치 설정
	obj.x = objx;
	obj.y = objy;

	missilebuttonList.push(obj);
}

function drawmissilebutton() {// 업버튼
	for (var i = 0; i < missilebuttonList.length; i++) {
		var tmp = missilebuttonList[i];
		for (var j = 0; j < missileList.length; j++) {
			var tmp2 = missileList[j];// 미사일
			if (tmp2.x < tmp.x + buttonsizeX && tmp2.x > tmp.x
					&& tmp2.y < tmp.y + buttonsizeX && tmp2.y > tmp.y) {// 족제비와
																		// 충돌시
																		// 작동
				tmp.check = true;
			}
		}
		context.drawImage(enemy2, tmp.x, tmp.y, buttonsizeX, buttonsizeX);
		context.drawImage(missilebutton, tmp.x - 25, tmp.y, buttonimagesizeX,
				buttonimagesizeY);
		if (tmp.check)
			context.drawImage(buttonL, tmp.x - 25, tmp.y, buttonimagesizeX,
					buttonimagesizeY);
	}
}