function map1(){
	
}

function map2(){
	clear_enemy();
}

function map3(){
	clear_enemy();
}

function map4(){
	clear_enemy();
	for(var i = 0; i < 10; i++){
		if(i == 4){
			continue;
		}
		makeEnemy(50*i,200);
	}
	for(var i = 0; i < 4; i++){
		makeEnemy(600,50*i);
	}
	makeiron1(0,150);
	makeiron2(0,0);
	makeiron3(550,0);
	makemissilebutton(300,100);
	
	for(var i = 0; i < 15; i++){
		if(i == 5 || i == 6){
			continue;
		}
		makeEnemy(50*i + 750,200);
	}
	makeiron2(650,0);
	makeiron3(900,0);
	makeiron2(1150,0);
	makeiron3(1450,0);
	makeiron1(900,150);
	makeiron4(1150,150);
	makeEnemy(950,0);
	makeEnemy(1100,0);
	makeEnemy(850,150);
	makeEnemy(1200,150);
	makemissilebutton(1400,100);
	
	for(var i = 0; i < 12; i++){
		if(i == 7 || i == 8){
			continue;
		}
		makeEnemy(50*i + 900,400);
	}
	
	makeiron(1000,200);
	makeiron(1050,200);
	makeiron(1250,400);
	makeiron(1300,400);
	makemissilebutton(1400,300);
	
	for(var i = 0; i < 8; i++){
		makeEnemy(50*i,400);
	}
	makeiron(200,200);
	makemissilebutton(0,300);
}

function clear_enemy() {
    if (enemyList.length > 0)
        enemyList.splice(0, enemyList.length);
    if (missileList.length > 0)
    	missileList.splice(0, missileList.length);
    if (ironList.length > 0)
    	ironList.splice(0, ironList.length);
    if (iron1List.length > 0)
    	iron1List.splice(0, iron1List.length);
    if (iron2List.length > 0)
    	iron2List.splice(0, iron2List.length);
    if (iron3List.length > 0)
    	iron3List.splice(0, iron3List.length);
    if (iron4List.length > 0)
    	iron4List.splice(0, iron4List.length);
    if (missilebuttonList.length > 0)
    	missilebuttonList.splice(0, missilebuttonList.length);
}