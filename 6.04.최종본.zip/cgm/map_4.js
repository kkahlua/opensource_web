function map1() {
	clear_enemy();
	 makeground();
	

	for(var i = 800/50; i < backgroundX/50; i++){
		  makeEnemy(i*50,400);
	  }
	  
	  for(var i = 400/50; i < backgroundY/50; i++){
		  makeEnemy(800,i*50);
	  }
	  
	
	  makebuttonup(900,300);
	  makebuttondown(1050,300);
	  
	  makeelevator(650,750,350);

	  setkey(50,50);
	  
	  makegatein(0,backgroundY-300);
	  makegateout(1200,150);
	  
	  setgolem(150,backgroundY-55);
	  setdamvi(150,backgroundY-55);
	  //makecube(400,backgroundY-200);
	  
	  //set_use_black();
	 
	 
	 
	  
}

function map2() {
	clear_enemy();
	 makeground();
		
	
	getCoin=false;
	makecube(400,600);
	makecube(490,400);
	makeEnemy(1200,350);
	makeEnemy(1100,400);
	makeEnemy(1100,350);
	makeEnemy(1100,300);
	
	
	
	makeEnemy(1200,450);
	makeEnemy(1150,450);
	makeEnemy(1100,450);
	
	
	makeEnemy(1100,250);
	for(var i =7;i<11;i++)
	{
		makeEnemy(50*i,550);
	}
	for(var i =11;i<14;i++)
	{
		makeEnemy(50*i,550);
	}for(var i =1;i<8;i++)
	{
		makeEnemy(350,550-50*i);
	}
	for(var i =1200/50;i<backgroundX/50;i++)
	{
		makeEnemy(50*i,300);
	}
	for(var i =1200/50;i<backgroundX/50;i++)
	{
		makeEnemy(50*i,250);
	}
	
	
	
	for(var i =1250/50;i<backgroundX/50;i++)
	{
		makeEnemy(50*i,550);
	}
	
	
	for(var i =0;i<400/50;i++)
	{
		makeEnemy(600,50*i);
	}
	
	for(var i =550/50;i<750/50;i++)
	{
		makeEnemy(1250,50*i);
	}
	
	makeEnemy(300,200);
	makeEnemy(250,200);
	makeEnemy(200,200);
	makeelevator(900,750,500);
	makebuttonup(1100,500);
	makebuttondown(400,650);
	
	
	 makeDoor(1400,100);
	  makeLock(1400,100);
	
	makegatein(0,backgroundY-300);
	makegateout(1200,0);
	setkey(200,50);
	setgolem(150,backgroundY-55);
	setdamvi(150,backgroundY-55);
	
	 set_use_black();
	
	 
}

function map3() {
	
	clear_enemy();
	makeground();
	for(var i =1100/50;i<backgroundX/50;i++)
	{
		makeEnemy(50*i,300);
	}
	makecube(500,600);
	makeEnemy(0,300);
	makeEnemy(50,300);
	makeEnemy(100,300);
	makeEnemy(150,300);
	makeEnemy(200,300);
	makeEnemy(250,300);
	makeEnemy(300,300);
	makeEnemy(350,300);
	
	makeelevator(900,750,605);
	makebuttonup(200,200);
	makebuttondown(1300,650);
	makeEnemy2(0,0);
	for(var i =0;i<4;i++)
	{
		makeEnemy(1100+50*i,470);
	}
	
	 makeDoor(1400,100);
	  makeLock(1400,100);
	
	  makegatein(0,backgroundY-300);
		makegateout(1200,0);
		
		  setkey(0,0);
		setgolem(150,backgroundY-55);
		setdamvi(150,backgroundY-55);
		 
		  set_use_black();
		  
		
}

function map4() {
	button_check = 0;
	clear_enemy();
	 makeground();
	for (var i = 0; i < 10; i++) {
		if (i == 4) {
			continue;
		}
		makeEnemy(50 * i, 200);
	}
	for (var i = 0; i < 4; i++) {
		makeEnemy(600, 50 * i);
	}
	makeiron1(0, 150);
	makeiron2(0, 0);
	makeiron3(550, 0);
	makemissilebutton(300, 100);

	for (var i = 0; i < 15; i++) {
		if (i == 5 || i == 6) {
			continue;
		}
		makeEnemy(50 * i + 750, 200);
	}
	makeiron2(650, 0);
	makeiron3(900, 0);
	makeiron2(1150, 0);
	makeiron3(1450, 0);
	makeiron1(900, 150);
	makeiron4(1150, 150);
	makeEnemy(950, 0);
	makeEnemy(1100, 0);
	makeEnemy(850, 150);
	makeEnemy(1200, 150);
	makemissilebutton(1400, 100);

	for (var i = 0; i < 12; i++) {
		if (i == 7 || i == 8) {
			continue;
		}
		makeEnemy(50 * i + 900, 400);
	}

	makeiron(1000, 200);
	makeiron(1050, 200);
	makeiron(1250, 400);
	makeiron(1300, 400);
	makemissilebutton(1400, 300);

	for (var i = 0; i < 8; i++) {
		makeEnemy(50 * i, 400);
	}
	makeiron(200, 200);
	makemissilebutton(0, 300);

	makemissilebutton(700, 650);
	
	setkey(50,50);
	makegatein(0,backgroundY-300);
	makegateout(1200,backgroundY-300);
	setgolem(150,backgroundY-55);
	setdamvi(150,backgroundY-55);
	
	  set_use_black();
	 
}
function map5(){
	clear_enemy();
	makeground5();
	
	for (var i = 0; i < 6; i++) {
		makeEnemy(50 * i, 150);
	}
	
	for (var i = 0; i < 10; i++) {
		makeEnemy(50 * i, 350);
	}
	
	for (var i = 0; i < 12; i++) {
		makeEnemy(1100, 50 * i + 150);
	}
	
	for (var i = 0; i < 4; i++) {
		makeEnemy(50 * i + 1150, 450);
	}
	
	makeelevator(900,750,600);
	makebuttonup(50,50);
	makebuttondown(1200,350);
	
	makecube(150,200);
	
	setkey(150,250);
	makegatein(0,backgroundY-300);
	makegateout(1200,backgroundY-300);
	setgolem(150,backgroundY-55);
	setdamvi(150,backgroundY-55);
	
	set_use_black();
}

function map6(){
	clear_enemy();
	makeground();
	makefan(300,backgroundY-150,450,1);
	makefan(backgroundX-450,backgroundY-150,450,1);
	for(var i = 450/50; i < backgroundX/50-450/50; i++){
		  makeEnemy(i*50,250);
	  }
	
	  for(var i = 750/50; i < backgroundX/50-450/50; i++){
		  makeEnemy(i*50,450);
	  }
	  
	  for(var i = 450/50; i <650/50; i++){
		  makeEnemy(i*50,450);
	  }
	  
	  
	  for(var i = 250/50; i < backgroundY/50; i++){
		  makeEnemy(450,i*50);
	  }
	  for(var i = 450/50; i < backgroundY/50; i++){
		  makeEnemy( backgroundX-500,i*50);
	  }
	  
	  for(var i = 650/50; i <backgroundY/50; i++){
		  makeEnemy(650,i*50);
		  makeEnemy(700,i*50);
	  }
	  
	  makecube(625,300);
	  setkey(850,600);
	
	  makegatein(0,backgroundY-300);
	  makegateout(1200,backgroundY-300);
	  
	  setgolem(150,backgroundY-55);
	  setdamvi(150,backgroundY-55);
	  
	  set_use_black();
}

function map7(){
	clear_enemy();
    makeground();
    makemissilebutton(0,0);
    
    makeEnemy(350,550);
    
    makeEnemy(250,150);
    makeEnemy(450,150);
    makeEnemy(600,150);
    makeEnemy(800,150);
    
    
    makeEnemy(0,150);
    makeEnemy(50,150);
    makeEnemy(100,150);
    makeiron2(150,100);
    makeiron1(150,50);
    makeiron3(1400,50);
    makeiron4(1400,100);
    makeiron(300,150);
    makeiron(350,150);
    makeiron(400,150);
    makeiron(750,150);
    makeiron(700,150);
    makeiron(650,150);
    makeiron(500,550);
    makeiron(450,550);
    makeiron(400,550);
    makeEnemy(550,550);


    makeEnemy(750,550);
    makeEnemy(700,550);
    makeEnemy(650,550);
    makeEnemy(800,550);
    makeEnemy(850,550);
    makeEnemy(850,500);
    makeEnemy(820,450);
    makeEnemy(790,400);
    makeEnemy(720,400);
    makeEnemy(680,450);
    makeEnemy(650,500);
    makeEnemy(0,350);
    makeEnemy(50,350);
    makeEnemy(100,350);
    makeEnemy(150,350);

    
   
    for(var i=0;i<6;i++)
    {
        makeEnemy(1200+50*i,450);
    }
    makemissilebutton(720,450);
    makegateout(1200,200);
    makegatein(0,backgroundY-300);
	
    makeelevator(1000,750,350);
    makebuttonup(1400,700);
    makebuttondown(0,250);
    
    setkey(0,0);
    
    setgolem(150,backgroundY-55);
	setdamvi(150,backgroundY-55);
    set_use_black();
}
function map8(){
	clear_enemy();
	 makeground();
	setgolem(150,backgroundY-55);
	setdamvi(150,backgroundY-55);
	makegatein(0,backgroundY-300);
	makegateout(-300,-300);
	setkey(-150,-150);
	
}


function clear_enemy() {
	if (enemyList.length > 0)
		enemyList.splice(0, enemyList.length);
	if (enemy2List.length > 0)
		enemy2List.splice(0, enemy2List.length);
	if (elevatorList.length > 0)
		elevatorList.splice(0, elevatorList.length);
	if (missileList.length > 0)
		missileList.splice(0, missileList.length);
	if (ironList.length > 0)
		ironList.splice(0, ironList.length);
	if (iron1List.length > 0)
		iron1List.splice(0, iron1List.length);
	if (iron2List.length > 0)
		iron2List.splice(0, iron2List.length);
	if (iron3List.length > 0)
		iron3List.splice(0, iron3List.length);
	if (iron4List.length > 0)
		iron4List.splice(0, iron4List.length);
	if (missilebuttonList.length > 0)
		missilebuttonList.splice(0, missilebuttonList.length);
	if (doorList.length > 0)
		doorList.splice(0, doorList.length);
	if (lockList.length > 0)
		lockList.splice(0, lockList.length);
	if (cubeList.length > 0)
		cubeList.splice(0, cubeList.length);
	
	if (buttonupList.length > 0)
		buttonupList.splice(0, buttonupList.length);
	if (buttondownList.length > 0)
		buttondownList.splice(0, buttondownList.length);
	if (hallList.length > 0)
		hallList.splice(0, hallList.length);
	
	if (fanList.length > 0)
		fanList.splice(0, fanList.length);
	if (set_blackList.length > 0)
		set_blackList.splice(0, set_blackList.length)
	
		true_misslebutton = 0;
	get_key = false;
	

}
