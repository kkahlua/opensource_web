var move = false;   //맵이동버튼 
var check = true;