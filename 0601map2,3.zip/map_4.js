function map1(){
	clear_enemy();
}

function map2(){
	getCoin=false;
	clear_enemy();
	makecube(400,600);
	makecube(900,400);
	for(var i =7;i<10;i++)
	{
		makeEnemy(50*i,550);
	}
	for(var i =11;i<22;i++)
	{
		makeEnemy(50*i,550);
	}for(var i =1;i<8;i++)
	{
		makeEnemy(350,550-50*i);
	}
	makeEnemy(300,200);
	makeEnemy(250,200);
	makeEnemy(200,200);
	makeelevator(1200,760,600);
	makebuttonup(1400,500);
	makebuttondown(250,100);
	makeEnemy(1450,200);
	makeEnemy(1400,200);

}

function map3(){
	getCoin=false;
	clear_enemy();
	makecube(500,600);
	makeEnemy(0,300);
	makeEnemy(50,300);
	makeEnemy(100,300);
	makeEnemy(150,300);
	makeEnemy(200,300);
	makeEnemy(250,300);
	makeEnemy(300,300);
	makeEnemy(350,300);
	makeEnemy(1350,200);
	makeEnemy(1300,200);
	makeEnemy(1450,200);
	makeEnemy(1400,200);
	makeelevator(900,750,600);
	makebuttonup(200,200);
	makebuttondown(1300,650);
	makeEnemy2(0,0);
	for(var i =0;i<4;i++)
	{
		makeEnemy(1100+50*i,470);
	}

}

function map4(){
	clear_enemy();
	for(var i = 0; i < 10; i++){
		if(i == 4){
			continue;
		}
		makeEnemy(50*i,200);
	}
	for(var i = 0; i < 4; i++){
		makeEnemy(600,50*i);
	}
	makeiron1(0,150);
	makeiron2(0,0);
	makeiron3(550,0);
	makemissilebutton(300,100);
	
	for(var i = 0; i < 15; i++){
		if(i == 5 || i == 6){
			continue;
		}
		makeEnemy(50*i + 750,200);
	}
	makeiron2(650,0);
	makeiron3(900,0);
	makeiron2(1150,0);
	makeiron3(1450,0);
	makeiron1(900,150);
	makeiron4(1150,150);
	makeEnemy(950,0);
	makeEnemy(1100,0);
	makeEnemy(850,150);
	makeEnemy(1200,150);
	makemissilebutton(1400,100);
	
	for(var i = 0; i < 12; i++){
		if(i == 7 || i == 8){
			continue;
		}
		makeEnemy(50*i + 900,400);
	}
	
	makeiron(1000,200);
	makeiron(1050,200);
	makeiron(1250,400);
	makeiron(1300,400);
	makemissilebutton(1400,300);
	
	for(var i = 0; i < 8; i++){
		makeEnemy(50*i,400);
	}
	makeiron(200,200);
	makemissilebutton(0,300);

}

function clear_enemy() {
    if (enemyList.length > 0)
        enemyList.splice(0, enemyList.length);
    if (missileList.length > 0)
    	missileList.splice(0, missileList.length);
    if (ironList.length > 0)
    	ironList.splice(0, ironList.length);
    if (iron1List.length > 0)
    	iron1List.splice(0, iron1List.length);
    if (iron2List.length > 0)
    	iron2List.splice(0, iron2List.length);
    if (iron3List.length > 0)
    	iron3List.splice(0, iron3List.length);
    if (iron4List.length > 0)
    	iron4List.splice(0, iron4List.length);
    if (missilebuttonList.length > 0)
    	missilebuttonList.splice(0, missilebuttonList.length);
    if(cubeList.length>0)
    	cubeList.splice(0,cubeList.length);
    if(elevatorList.length>0)
    	elevatorList.splice(0,elevatorList.length);
    if(buttonupList.length>0)
    	buttonupList.splice(0,buttonupList.length);
    if(buttondownList.length>0)
    	buttondownList.splice(0,buttondownList.length);


}