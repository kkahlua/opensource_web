
var coin = new Image();
coin.src = "image/coin.png";
var _frame=0;
var _maxFrame =6;

function drawCoinM2() {

    context.drawImage(coin, _frame %3, Math.floor(_frame / 3) * 3000,
     2400, 2400, 100, 300, 100, 100);
    _frame = (_frame + 0.1) % _maxFrame;            
}

function drawCoinM3() {

    context.drawImage(coin, _frame %3, Math.floor(_frame / 3) * 3000,
     2400, 2400, 1400, 300, 100, 100);
    _frame = (_frame + 0.1) % _maxFrame;            
}

function coinM2(){
    if(myairX<=200&&myairX>=100&&myairY<=400&&myairY>=300)
    {
      getCoin=true;
    }
    if(getCoin==false)
    drawCoinM2();
}
function coinM3(){
    if(myairX<=1400&&myairX>=1300&&myairY<=350&&myairY>=300)
    {
      getCoin=true;
    }
    if(getCoin==false)
    drawCoinM3();
}
