var mouse = false // 마우스 상태
var mouseX = 0; // 마우스x 위치
var mouseY = 0; // 마우스y 위치
var mouselog = 0; // 유저로부터 마우스 길이
var groundsizeY = 50;
var groundsizeX = 50;
var h = 800;
var w = 1500;

/* 미사일 */
var missile = new Image(); // 미사일 이미지
missile.src = "image/missile.png";
var missileList = []; // 미사일 객체 리스트
var missileSpeed = 1; // 미사일 속도
var keypress = false; // 미사일 누르기
var missileDelay = 100; // 발사속도

// 튕기는 철 블럭 지정
var iron = new Image();
iron.src = "image/iron.png";
var ironList = [];

//튕기는 철1 블럭 지정
var iron1 = new Image();
iron1.src = "image/iron1.png";
var iron1List = [];

//튕기는 철2 블럭 지정
var iron2 = new Image();
iron2.src = "image/iron2.png";
var iron2List = [];

//튕기는 철3 블럭 지정
var iron3 = new Image();
iron3.src = "image/iron3.png";
var iron3List = [];

//튕기는 철4 블럭 지정
var iron4 = new Image();
iron4.src = "image/iron4.png";
var iron4List = [];

// 미사일 만들기 내 비행기에서 나가는 거
function makeMissile() {

	if (keypress == true) { // 마우스 키가 눌렸을 때
		if (missileDelay < 0) { // 연사 딜레이
			var obj = {};
			obj.x = myairX + 12;
			obj.y = myairY - 10;
			obj.speedx = missileSpeed / mouselog * mouseX;
			obj.speedy = missileSpeed / mouselog * mouseY;
			obj.isDead = false;
			missileList.push(obj);
			// 마우스 클릭 위치를 바라보게 하기
	          var angle = -Math.atan2(mouseX,mouseY) * 180 / Math.PI;
	          obj.ang = angle;
	          if(angle>0&&angle<=90){
	        	  obj.direc = 0; //으론쪽 위
	          }
	          else if(angle>90&&angle<=180){
	        	  obj.direc = 1; // 오른쪽 아래
	          }
	          else if(angle>-90&&angle<=0){
	        	  obj.direc = 2; // 왼쪽 위
	          }
	          else{
	        	  obj.direc = 3; // 왼쪽 아래
	          }
	        	console.log('각도' + angle );
// if (st >= 10) { // 미사일 효과음 집어 넣을려다가 저작권 때문에 뻈습니다.
// st = 0;
// }
			missileDelay = 200;
		}
	}
}
// 미사일 그리기
function drawMissile() {
	for (var i = 0; i < missileList.length; i++) {
		var temp = missileList[i];
		
	      for (var j = 0; j < ironList.length; j++) {  // 우충돌판정
	    	  var tar = ironList[j];
    		  if(temp.x < tar.x + groundsizeX && temp.x > tar.x && temp.y < tar.y + groundsizeY && temp.y > tar.y){
			  temp.speedy = -temp.speedy;
			  temp.ang = -temp.ang;
			  console.log('부딪힘');
		  }
//	    	  if(temp.direc == 0){
//	    		  if(temp.x < tar.x + 1 && temp.x > tar.x && temp.y < tar.y + groundsizeY && temp.y > tar.y){
//	    			  temp.direc = 2;
//	    			  temp.speedx = -temp.speedx;
//	    			  temp.ang = -temp.ang;
//	    			  console.log('부딪힘');
//	    		  }
//	    		  else if(temp.x < tar.x + groundsizeX && temp.x > tar.x && temp.y < tar.y + groundsizeY && temp.y > tar.y + groundsizeY - 1){
//	    			  temp.direc = 1;
//	    			  temp.speedy = -temp.speedy;
//	    			  temp.ang = -temp.ang;
//	    			  console.log('부딪힘');
//	    		  }
//	    	  }
//	    	  else if(temp.direc == 1){
//	    		  if(temp.x < tar.x + 1 && temp.x > tar.x && temp.y < tar.y + groundsizeY && temp.y > tar.y){
//	    			  temp.direc = 3;
//	    			  temp.speedx = -temp.speedx;
//	    			  temp.ang = -temp.ang;
//	    			  console.log('부딪힘');
//	    		  }
//	    		  else if(temp.x < tar.x + groundsizeX && temp.x > tar.x && temp.y < tar.y  && temp.y > tar.y - 1){
//	    			  temp.direc = 0;
//	    			  temp.speedy = -temp.speedy;
//	    			  temp.ang = -temp.ang;
//	    			  console.log('부딪힘');
//	    		  }
//	    	  }
//	    	  else if(temp.direc == 2){
//	    		  if(temp.x < tar.x + groundsizeX && temp.x > tar.x + groundsizeX - 1 && temp.y < tar.y + groundsizeY && temp.y > tar.y){
//	    			  temp.direc = 0;
//	    			  temp.speedx = -temp.speedx;
//	    			  temp.ang = -temp.ang;
//	    			  console.log('부딪힘');
//	    		  }
//	    		  else if(temp.x < tar.x + groundsizeX && temp.x > tar.x && temp.y < tar.y + groundsizeY && temp.y > tar.y + groundsizeY - 1){
//	    			  temp.direc = 3;
//	    			  temp.speedy = -temp.speedy;
//	    			  temp.ang = -temp.ang;
//	    			  console.log('부딪힘');
//	    		  }
//	    	  }
//	    	  else if(temp.direc == 3){
//	    		  if(temp.x < tar.x + groundsizeX && temp.x > tar.x + groundsizeX - 1 && temp.y < tar.y + groundsizeY && temp.y > tar.y){
//	    			  temp.direc = 1;
//	    			  temp.speedx = -temp.speedx;
//	    			  temp.ang = -temp.ang;
//	    			  console.log('부딪힘');
//	    		  }
//	    		  else if(temp.x < tar.x + groundsizeX && temp.x > tar.x && temp.y < tar.y  && temp.y > tar.y - 1){
//	    			  temp.direc = 2;
//	    			  temp.speedy = -temp.speedy;
//	    			  temp.ang = -temp.ang;
//	    			  console.log('부딪힘');
//	    		  }
//	    	  }
	      }
	      for (var j = 0; j < iron1List.length; j++) {  // 우충돌판정
	    	  var tar = iron1List[j];
	    	  if(temp.x > tar.x && temp.y < tar.y + groundsizeY && temp.y > temp.x-tar.x+tar.y&&temp.x < temp.y+tar.x-tar.y ){
                  temp.a = temp.speedy;

                  temp.b = temp.speedx;
                  temp.speedy=temp.b;
                  temp.speedx=temp.a;
                  temp.ang = -temp.ang+90;
                  temp.a=true;

                  console.log('부딪힘');
              }
	      }
	      
	      for (var j = 0; j < iron2List.length; j++) {  // 우충돌판정
	    	  var tar = iron2List[j];
	    	  if(temp.x > tar.x && temp.y > tar.y && temp.y < -temp.x+tar.x+tar.y+groundsizeY&&temp.x < -temp.y+tar.x+tar.y+groundsizeX ){
                  temp.a = -temp.speedy;

                  temp.b = -temp.speedx;
                  temp.speedy=temp.b;
                  temp.speedx=temp.a;
                  temp.ang = -temp.ang+90;
                  temp.a=true;

                  console.log('부딪힘');
              }
	      }
	      
	      for (var j = 0; j < iron3List.length; j++) {  // 우충돌판정
	    	  var tar = iron3List[j];
	    	  if(temp.x < tar.x + groundsizeX  && temp.y > tar.y && temp.y < temp.x-tar.x+tar.y&&temp.x > temp.y+tar.x-tar.y ){
                  temp.a = temp.speedy;

                  temp.b = temp.speedx;
                  temp.speedy=temp.b;
                  temp.speedx=temp.a;
                  temp.ang = -temp.ang+90;
                  temp.a=true;

                  console.log('부딪힘');
              }
	      }
	      
	      for (var j = 0; j < iron4List.length; j++) {  // 우충돌판정
	    	  var tar = iron4List[j];
	    	  if(temp.x < tar.x + groundsizeX && temp.y < tar.y + groundsizeY && temp.y > -temp.x+tar.x+tar.y+groundsizeY&&temp.x > -temp.y+tar.x+tar.y+groundsizeX ){
                  temp.a = -temp.speedy;

                  temp.b = -temp.speedx;
                  temp.speedy=temp.b;
                  temp.speedx=temp.a;
                  temp.ang = -temp.ang+90;
                  temp.a=true;

                  console.log('부딪힘');
              }
	      }
	      
	      var angle = temp.ang;
		  if(angle>0&&angle<=90){
        	  temp.direc = 0; //으론쪽 위
          }
          else if(angle>90&&angle<=180){
        	  temp.direc = 1; // 오른쪽 아래
          }
          else if(angle>-90&&angle<=0){
        	  temp.direc = 2; // 왼쪽 위
          }
          else{
        	  temp.direc = 3; // 왼쪽 아래
          }
	      
        context.save(); // 값 설정 저장
        context.translate(temp.x, temp.y); // 위치 설정
        context.rotate(temp.ang * Math.PI / 180); // 플레이어를 향해 보기
        context.drawImage(missile, 0,0, 7, 32); // 그리기
        context.restore(); // 값 설정 저장 풀기
	}
}

// 미사일 이동
function moveMissile() {
	for (var i = 0; i < missileList.length; i++) {
		var temp = missileList[i];

		temp.x = temp.x - (temp.speedx*5);// 미사일각각의 속도로 날아가기
		temp.y = temp.y - (temp.speedy*5);
		if (temp.y <= -40 || temp.y >=840 || temp.x <= -40 || temp.x >= 1540) {
			temp.isDead = true;
	    }
	}
}
// 미사일 제거
function removeMissile() {

	for (var i = missileList.length - 1; i >= 0; i--) {
		var temp = missileList[i];
		

		if (temp.isDead) {
			missileList.splice(i, 1);
		}
	}
}

function checkMissile(){
	for (var i = 0; i < missileList.length; i++) {
		var temp = missileList[i];
	 for (var i = 0; i < enemyList.length; i++) {
         var tar = enemyList[i];
         if (temp.x < tar.x + 50 && temp.x > tar.x && temp.y < tar.y + 50 && temp.y > tar.y) {
         	temp.isDead = true;
         }
     }
	}
}
document.addEventListener("mousedown", mouse_press, false);
document.addEventListener("mouseup", mouse_up, false);
document.addEventListener("mousemove", onMouseMove, false);

function onMouseMove() {// 마우스 위치추적에 사용
	if ((myairX - event.pageX + 15) != 0) {// 0으로 나누는 연산방지
		mouseX = myairX - event.pageX + 15;// 본체로부터 마우스 상대위치 계산 본체위치-마우스위치
	}
	if ((myairX - event.pageY - 15) != 0) {
		mouseY = myairY - event.pageY - 15;
	}
	mouselog = Math.sqrt(mouseX * mouseX + mouseY * mouseY);// 본체와 마우스 사이 거리계산
															// 미사일 속도 계산에 사용됨
}

function mouse_press() {// 마우스 누름

	keypress = true;
	mouse = true;

}
function mouse_up()// 마우스 땜
{

	keypress = false;
	mouse = false;

}


// 튕기는 블럭 만들기
function makeiron(objx,objy) {
    var obj = {};
    obj.x = objx;
    obj.y = objy;
    ironList.push(obj);
  }

//튕기는 블럭1 만들기
function makeiron1(objx,objy) {
    var obj = {};
    obj.x = objx;
    obj.y = objy;
    iron1List.push(obj);
  }

//튕기는 블럭2 만들기
function makeiron2(objx,objy) {
    var obj = {};
    obj.x = objx;
    obj.y = objy;
    iron2List.push(obj);
  }

//튕기는 블럭3 만들기
function makeiron3(objx,objy) {
    var obj = {};
    obj.x = objx;
    obj.y = objy;
    iron3List.push(obj);
  }

//튕기는 블럭4 만들기
function makeiron4(objx,objy) {
    var obj = {};
    obj.x = objx;
    obj.y = objy;
    iron4List.push(obj);
  }

//function makeAlliron(){
//  	 makeiron(300,h-groundsizeY-200);
//  	 
//  	makeiron1(500,h-groundsizeY-200);
//  	makeiron2(700,h-groundsizeY-200);
//  	makeiron3(900,h-groundsizeY-200);
//  	makeiron4(1100,h-groundsizeY-200);
//}

function drawiron(){
    for(var i =0;i<ironList.length;i++)
    {
      var tmp = ironList[i];
      
      context.drawImage(iron,tmp.x,tmp.y,groundsizeX,groundsizeY);
    }
    for(var i =0;i<iron1List.length;i++)
    {
      var tmp = iron1List[i];
      
      context.drawImage(iron1,tmp.x,tmp.y,groundsizeX,groundsizeY);
    }
    for(var i =0;i<iron2List.length;i++)
    {
      var tmp = iron2List[i];
      
      context.drawImage(iron2,tmp.x,tmp.y,groundsizeX,groundsizeY);
    }
    for(var i =0;i<iron3List.length;i++)
    {
      var tmp = iron3List[i];
      
      context.drawImage(iron3,tmp.x,tmp.y,groundsizeX,groundsizeY);
    }
    for(var i =0;i<iron4List.length;i++)
    {
      var tmp = iron4List[i];
      
      context.drawImage(iron4,tmp.x,tmp.y,groundsizeX,groundsizeY);
    }
  }