
      var start_do = 0; // 시작했는지 안했는지
      var home_do = 0; // 홈을 눌렀는지 안했는지
      var homebar_do = 0; // 홈 바를 눌렀는지 안했는지
      var music_do = 1; // 배경음악이 들리는가
      var sound_do = 1; // 효과음 들리는가
      var map_do = 0; // 맵이 열렸는지
      var mobile_do = 0;
      
      var home = new Image(); // 홈 이미지
      home.src = "image/home.png";
      
      var play = new Image(); // 플레이 이미지
      play.src = "image/main/title.png";
      
      var homebar = new Image(); // 홈_바 이미지
      homebar.src = "image/home_bar.png";
      
      var menu = new Image(); // 메뉴 이미지
      menu.src = "image/menu.png";
      
      var replay = new Image(); // 리플레이 이미지
      replay.src = "image/replay.png";
      
      var mobile_up = new Image(); // 리플레이 이미지
      mobile_up.src = "image/mobile_up.png";
      
      var mobile_left = new Image(); // 리플레이 이미지
      mobile_left.src = "image/mobile_left.png";
      
      var mobile_right = new Image(); // 리플레이 이미지
      mobile_right.src = "image/mobile_right.png";
      
      var mobile_button_do = new Image(); // 리플레이 이미지
      mobile_button_do.src = "image/mobile_button_do.png";
    	
      
      var mobile_ui_not = new Image(); // 플레이 이미지
      mobile_ui_not.src = "image/main/title_mobileUI.png";
      
      var mobile_ui_sel = new Image(); // 플레이 이미지
      mobile_ui_sel.src = "image/main/title_mobileUI_select.png";
      
      
      // 시작 버튼
		class Circle{
			draw(context){
				context.drawImage(play, 0,0, 1500, 800); // 그리기
			}
			
			clickCircle(xmouse,ymouse){
				if(xmouse > 1222 && xmouse < 1353 && ymouse > 314 && ymouse < 341){
					console.log('clicked play');
					start_do = 1;
					home_do = 1;
					map_do = 1;
					playAudio();
					start();
					return true;
				} else if(xmouse > 1222 && xmouse < 1353 && ymouse > 410 && ymouse < 442){
					console.log('clicked mobile');
					if(mobile_do){
						mobile_do = 0;
						context.drawImage(play, 0,0, 1500, 800); // 그리기
						context.drawImage(mobile_ui_not, 0,0, 1500, 800); // 그리기
					}
					else{
						mobile_do = 1;
						context.drawImage(play, 0,0, 1500, 800); // 그리기
						context.drawImage(mobile_ui_sel, 0,0, 1500, 800); // 그리기
					}
					return true;
				}else{
					return false;
				}
			}
		}
		
		// 홈 버튼
		class Home1{
			draw(context){
				context.drawImage(home, 0, 0, 50, 50); // 그리기
			}

			clickHome(xmouse,ymouse){
				if(xmouse > 0 && xmouse < 50 && ymouse > 0 && ymouse < 50){
					console.log('clicked home');
					home_do = 1;
					if(homebar_do == 1)
						homebar_do = 0;
					else
						homebar_do = 1;
					return true;
				}else{
					return false;
				}
			}
		}
		
		// 홈바 버튼
		class Home_bar{
			draw(context){
				context.drawImage(homebar, 350, 50, 800, 700); // 그리기
				musicof.draw(context);
				soundof.draw(context);
				replay_button.draw(context);
				context.drawImage(menu, 650,200,200,100);
			}
			
			clickHomebar(xmouse,ymouse){
				if(xmouse > 650 && xmouse < 850 && ymouse > 200 && ymouse < 300){
					console.log('clicked menu');
					home_do = 0;
					map_do = 1;
					homebar_do = 0;
					GoMap();
					return true;
				}else{
					return false;
				}
			}
		}
		// 배경음악온오프 버튼
		class Musicof{
			draw(context){
				if(music_do == 1)
					context.drawImage(musicOn, 600, 450, 100, 100); // 그리기
				else
					context.drawImage(musicOff, 600, 450, 100, 100); // 그리기
			}
			
			clickMusic(xmouse,ymouse){
				if(xmouse > 600 && xmouse < 700 && ymouse > 450 && ymouse < 550){
					console.log('clicked home');
					if(music_do == 1){
						stopAudio();
						music_do = 0;
					}else{
						playAudio();
						music_do = 1;
					}
					return true;
				}else{
					return false;
				}
			}
		}
		// 효과음온오프 버튼
		class Soundof{
			draw(context){
				if(sound_do == 1)
					context.drawImage(soundOn, 800, 450, 100, 100); // 그리기
				else
					context.drawImage(soundOff, 800, 450, 100, 100); // 그리기
			}
			
			clickSound(xmouse,ymouse){
				if(xmouse > 800 && xmouse < 900 && ymouse > 450 && ymouse < 550){
					console.log('clicked home');
					if(sound_do == 1)
						sound_do = 0;
					else
						sound_do = 1;
					return true;
				}else{
					return false;
				}
			}
		}
		
		//리플레이 버튼
		class Replay_button{
			draw(context){
					context.drawImage(replay, 700, 350, 100, 100); // 그리기
			}
			
			clickreplay(xmouse,ymouse){
				if(xmouse > 700 && xmouse < 800 && ymouse > 350 && ymouse < 450){
					console.log('clicked replay');
					homebar_do = 0;
					GoMap();
					start();
					return true;
				}else{
					return false;
				}
			}
		}
		
		//모바일 버튼
		class Mobile_button{
			draw(context){
					context.drawImage(mobile_up, 100, 700, 100, 100); // 그리기
					context.drawImage(mobile_left, 0, 700, 100, 100); // 그리기
					context.drawImage(mobile_right, 200, 700, 100, 100); // 그리기
					context.drawImage(mobile_left, 1300, 700, 100, 100); // 그리기
					context.drawImage(mobile_right, 1400, 700, 100, 100); // 그리기
			}
			
			clickmobile_dam_left(xmouse,ymouse){
				if(xmouse > 0 && xmouse < 100 && ymouse > 700 && ymouse < 800){
					leftkey = true;
					setTimeout(function() {
						  leftkey = false;
						}, 1000);
					console.log('누름');
					return true;
				}
				else{
					return false;
				}
			}
			clickmobile_dam_up(xmouse,ymouse){
				if(xmouse > 100 && xmouse < 200 && ymouse > 700 && ymouse < 800){
					spacebar = true;
					setTimeout(function() {
						spacebar = false;
						}, 1000);
					return true;
				}
				else{
					return false;
				}
			}
			clickmobile_dam_right(xmouse,ymouse){
				if(xmouse > 200 && xmouse < 300 && ymouse > 700 && ymouse < 800){
					rightkey = true;
					setTimeout(function() {
						rightkey = false;
						}, 1000);
					return true;
				}
				else{
					return false;
				}
			}
			clickmobile_gol_left(xmouse,ymouse){
				if(xmouse > 1300 && xmouse < 1400 && ymouse > 700 && ymouse < 800){
					akey = true
					setTimeout(function() {
						akey = false;
						}, 1000);
					return true;
				}
				else{
					return false;
				}
			}
			clickmobile_gol_right(xmouse,ymouse){
				if(xmouse > 1400 && xmouse < 1500 && ymouse > 700 && ymouse < 800){
					dkey = true;
					setTimeout(function() {
						dkey = false;
						}, 1000);
					return true;
				}
				else{
					return false;
				}
			}
		}
		
		function drawtext(){
			context.fillStyle = "purple";

			context.font = "italic bold 40px Arial, sans-serif";

			context.fillText(map_count+"번째 맵", 700, 50);

			context.lineWidth = 2; //외곽선의 크기 설정

			context.strokeText(map_count+"번째 맵", 700, 50); // 외곽선만 있는 글씨 표시
		}
			
      
  		let circle = new Circle();
  		let home1 = new Home1();
  		let home_bar = new Home_bar();
		let musicof = new Musicof();
		let soundof = new Soundof();
		let replay_button = new Replay_button();
		let mobile_button = new Mobile_button();