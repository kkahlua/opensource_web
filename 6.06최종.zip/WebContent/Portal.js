var R_portal = new Image();
R_portal.src = "image/R_portal.png";
var Rp_frame=0;
var Rp_maxFrame=8;
var L_portal = new Image();
L_portal.src = "image/L_portal.png";
var Lp_frame=0;
var Lp_maxFrame=8;

function drawR_portalMotionM3(){
    context.drawImage(R_portal, Rp_frame % 4, Math.floor(Rp_frame / 4),
       70, 70, 50, 150, 200, 200);
    Rp_frame = (Rp_frame + 0.1)% Rp_maxFrame;
}


function drawL_portalMotionM3(){
    context.drawImage(L_portal, Lp_frame % 4, Math.floor(Lp_frame / 4),
       70, 70, 1100, 300, 200, 200);
    Lp_frame = (Lp_frame + 0.1)% Lp_maxFrame;
}

function telpoM3(){
if(myairX<=139&&myairX>=135&&myairY<=300&&myairY>=190)
    {

      myairX=1100;
      myairY=400
  }

  if(myairX<=1200&&myairX>=1175&&myairY<=500&&myairY>=360)
  {
      myairX=110;
      myairY=272;
  }
  drawR_portalMotionM3();
  drawL_portalMotionM3(); 
}
function drawR_portalMotionM7(){
    context.drawImage(R_portal, Rp_frame % 4, Math.floor(Rp_frame / 4),
       70, 70, 50, 150, 250, 200);
    Rp_frame = (Rp_frame + 0.1)% Rp_maxFrame;
}
function drawL_portalMotionM7(){
    context.drawImage(L_portal, Lp_frame % 4, Math.floor(Lp_frame / 4),
       70, 70, 1350, 500, 200, 200);
    Lp_frame = (Lp_frame + 0.1)% Lp_maxFrame;
}

function telpoM7(){
    if(myairX<=152&&myairX>=148&&myairY<=350&&myairY>=240)
    {

      myairX=1300;
      myairY=600
  }

  if(myairX<=1470&&myairX>=1400&&myairY<=650&&myairY>=560)
  {
      myairX=50;
      myairY=250;
  }
  drawR_portalMotionM7();
  drawL_portalMotionM7();
}