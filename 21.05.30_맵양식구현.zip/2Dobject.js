
//문
var door = new Image();
door.src = "image/door.png";
var doorsizeX = 100;
var doorsizeY = 100;
var doorList = [];
//잠긴문
var lock = new Image();
lock.src = "image/lock.png";
var locksizeX = 100;
var locksizeY = 100;
var lockList = [];



function drawDoor(){
	for(var i =0;i<doorList.length;i++)
	{
		var tmp = doorList[i];
		context.drawImage(door,tmp.x,tmp.y,doorsizeX,doorsizeY);
	}
}
function drawLock(){
	for(var i =0;i<lockList.length;i++)
	{
		var tmp = lockList[i];
		context.drawImage(lock,tmp.x,tmp.y,locksizeX,locksizeY);
	}
}


function makeLock(objx,objy) {
	var obj = {};
	obj.x = objx;
	obj.y = objy;
	lockList.push(obj);
}
function makeDoor(objx,objy) {
	var obj = {};
	obj.x = objx;
	obj.y = objy;
	doorList.push(obj);
}

function makeAllDoor()
{
       makeDoor(1400,100);
}
function makeAllLock()
{
	makeLock(1400,100); 
}
