var ground4 = new Image();
ground4.src = "image/black2.png";
var ground4List = [];

function makeground4(objx, objy) {// 충돌 오브젝트

	var obj = {};
	// 위치 설정
	obj.x = objx;
	obj.y = objy;

	ground4List.push(obj);
}

function drawground4() {//충돌 판정 그리기
    for (var i = 0; i < ground4List.length; i++) {
        var tmp = ground4List[i];
        //족제비 좌우 충돌 쓰일 일이 있을지는 모르겠음.
      	if(myairX < tmp.x + black0sizeX && myairX > tmp.x - (my0sizeX) && myairY < tmp.y + black0sizeY && myairY > tmp.y - my0sizeY+5){
      		//5정도는 떨어트려놔야 위쪽에 있을때 반응안함
  			if(myairX < tmp.x + black0sizeX/2-(my0sizeX)/2){
  				myairX=tmp.x - (my0sizeX)
  			}
  			else{
  				myairX=tmp.x + black0sizeX
  			}
  			if(myairY < tmp.y + black0sizeX/2-(my0sizeY)/2){
  			}
  		}
        context.drawImage(ground4, tmp.x, tmp.y, black0sizeX, black0sizeY);
    }

}

function map1(){
	removemap4();
}

function map2(){
	removemap4();
}

function map3(){
	removemap4();
}

function map4(){
	makeground4(650,300);
}

function removemap4() {
    for (var i = ground4List.length - 1; i >= 0; i--) {
        var temp = ground4List[i];
        ground4List.splice(i, 1);	// 미사일을 리스트에서 제거 
    }
}