function map1(){
	
}

function map2(){
	clear_enemy();
}

function map3(){
	clear_enemy();
}

function map4(){
	makeEnemy(650,300);
}

function clear_enemy() {
    for (var i = enemyList.length - 1; i >= 0; i--) {
        var temp = enemyList[i];
        enemyList.splice(i, 1);	// 미사일을 리스트에서 제거 
    }
}