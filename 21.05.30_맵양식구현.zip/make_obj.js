/*-----------------------------------------<비>충돌오브젝트------------------------------------------------------*/
      
      
      function makebuttonup(objx,objy) {//버튼업
  
           
            var obj = {};
            // 위치 설정
            obj.x = objx;
            obj.y = objy;
          
            buttonupList.push(obj);

        }
      function makebuttondown(objx,objy) {//버튼다운
    	  
          
          var obj = {};
          // 위치 설정
          obj.x = objx;
          obj.y = objy;
        
          buttondownList.push(obj);

      }
      
      
      /*-----------------------------------------충돌오브젝트------------------------------------------------------*/
      
      function makeEnemy(objx,objy) {//충돌 오브젝트
  
           
            var obj = {};
            // 위치 설정
            obj.x = objx;
            obj.y = objy;
          
            enemyList.push(obj);

        }

      
      function makeEnemy2() {//엘리베이터 위쪽오브젝트 생성
    	  
          
          var obj = {};
          // 위치 설정
          obj.x = 0;
          obj.y = 0;
        
          enemy2List.push(obj);

      }
      
      function makegatein(objx,objy) {//엘리베이터 위쪽오브젝트 생성
    	  
    	  gateinX=objx;
          gateinY=objy;


      }
      
	  function makecube(objx,objy) {//큐브 생성
    	  
          
          var obj = {};
          // 위치 설정
          obj.x = objx;
          obj.y = objy;
          obj.speedx = 0;
          obj.speedy = 0;
          
          
          cubeList.push(obj);

      }
      
      /*-----------------------------------------------------------------엘리베이터--------------------------------------------------------------------*/
   	 
      function makeelevator(objx,objy,endY) {//x위치,y위치,이동가능 범위
   		var obj = {};
   		obj.objList=[]//엘리베이터와 위치가 겹치는 충돌판정 오브젝트 리스트
   		for(var i = 0; i < elevatorsizeX/50; i++){//자신 위치에 충돌 판정 오브젝트 생성할 위치 결정
   			for(var j = 0; j < elevatorsizeY/50; j++){
   				makeEnemy(objx+50*i,objy+50*j+black1sizeY);//자신 위치에 충돌 오브젝트 생성
   				}
   			}
   		for (var i = 0; i < enemyList.length; i++) {
            var tar = enemyList[i];
            if(objx < tar.x + black0sizeX && objx > tar.x - (elevatorsizeX) && objy < tar.y + black0sizeY && objy > tar.y - elevatorsizeY)
            	//엘리베이터와 위치가 겹치는 충돌판정 리스트 확보
            	{
            		obj.objList.push(i);//엘리베이터와 위치가 겹치는 충돌판정들의 리스트 만듬
            	}
            
   		}
   		
   		  makeEnemy2();///엘리베이터 위쪽오브젝트 생성
          
          
          // 위치 설정
          obj.x = objx;
          obj.y = objy-black1sizeY;
          obj.speedx = 0;
          obj.speedy = 0;
          obj.limitstartY = objy-black1sizeY;
          obj.limitendY = objy-endY;
          obj.up = false;
          obj.down = false;
        
          elevatorList.push(obj);

      }