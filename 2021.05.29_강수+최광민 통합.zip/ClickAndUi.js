canvas.style.background = "#a6e1f5";
      
      var start_do = 0; // 시작했는지 안했는지
      var home_do = 0; // 홈을 눌렀는지 안했는지
      var homebar_do = 0; // 홈 바를 눌렀는지 안했는지
      var music_do = 1; // 배경음악이 들리는가
      var sound_do = 1; // 효과음 들리는가
      var map_do = 0; // 맵이 열렸는지
      var map_count = 0; // 몇번째 맵이 클릭 됬는지
      
      var musicOn = new Image(); // 배경음악 온 이미지
      musicOn.src = "image/musicOn.png";
      var musicOff = new Image(); // 배경음악 오프 이미지
      musicOff.src = "image/musicOff.png";
      
      var soundOn = new Image(); // 효과음 온 이미지
      soundOn.src = "image/soundOn.png";
      var soundOff = new Image(); // 효과음 오프 이미지
      soundOff.src = "image/soundOff.png";
      
      var home = new Image(); // 홈 이미지
      home.src = "image/home.png";
      
      var play = new Image(); // 플레이 이미지
      play.src = "image/play.png";
      
      var homebar = new Image(); // 홈_바 이미지
      homebar.src = "image/home_bar.png";
      
      var map = new Image(); // 맵 이미지
      map.src = "image/map.png";
      
      var menu = new Image(); // 메뉴 이미지
      menu.src = "image/menu.png";

      canvas.addEventListener('click', (event) =>{
      	const rect = canvas.getBoundingClientRect();
      	const x = event.clientX - rect.left;
      	const y = event.clientY - rect.top;
      	if(start_do == 0)
      		circle.clickCircle(x,y);
      	if(home_do == 1)
      		home1.clickHome(x,y);
      	if(homebar_do == 1){
      		musicof.clickMusic(x,y);
      		soundof.clickSound(x,y);
      		home_bar.clickHomebar(x,y);
      	}
      	if(map_do == 1){
      		mapdr.clickMap1(x,y);
      		mapdr.clickMap2(x,y);
      	}
      	console.log('x: ' + x + ' y: ' + y);
      });
      
      function playAudio() {
    	  audioContainer.volume = 0.2;
    	  audioContainer.loop = true;
    	  audioContainer.play();
    	  
    	}

    	function stopAudio() {
    	  audioContainer.pause();  
    	}
    	
    	// 생성자 함수로 Audio 객체 생성
    	function jump_audio() {
    	  var audio = new Audio('jump.mp3');
    	  audio.play();
    	}
    	
      // 시작 버튼
		class Circle{
			draw(context){
				context.drawImage(play, 650,500, 200, 100); // 그리기
			}
			
			clickCircle(xmouse,ymouse){
				if(xmouse > 650 && xmouse < 850 && ymouse > 500 && ymouse < 600){
					console.log('clicked play');
					start_do = 1;
					home_do = 1;
					map_do = 1;
// playAudio();
					GoMap();
					return true;
				}else{
					return false;
				}
			}
		}
		
		// 홈 버튼
		class Home1{
			draw(context){
				context.drawImage(home, 0, 0, 50, 50); // 그리기
			}

			clickHome(xmouse,ymouse){
				if(xmouse > 0 && xmouse < 50 && ymouse > 0 && ymouse < 50){
					console.log('clicked home');
					home_do = 1;
					if(homebar_do == 1)
						homebar_do = 0;
					else
						homebar_do = 1;
					return true;
				}else{
					return false;
				}
			}
		}
		
		// 홈바 버튼
		class Home_bar{
			draw(context){
				context.drawImage(homebar, 350, 50, 800, 700); // 그리기
				musicof.draw(context);
				soundof.draw(context);
				context.drawImage(menu, 650,200,200,100);
			}
			
			clickHomebar(xmouse,ymouse){
				if(xmouse > 650 && xmouse < 850 && ymouse > 200 && ymouse < 300){
					console.log('clicked menu');
					home_do = 0;
					map_do = 1;
					homebar_do = 0;
					GoMap();
					return true;
				}else{
					return false;
				}
			}
		}
		// 배경음악온오프 버튼
		class Musicof{
			draw(context){
				if(music_do == 1)
					context.drawImage(musicOn, 600, 450, 100, 100); // 그리기
				else
					context.drawImage(musicOff, 600, 450, 100, 100); // 그리기
			}
			
			clickMusic(xmouse,ymouse){
				if(xmouse > 600 && xmouse < 700 && ymouse > 450 && ymouse < 550){
					console.log('clicked home');
					if(music_do == 1){
						stopAudio();
						music_do = 0;
					}else{
						playAudio();
						music_do = 1;
					}
					return true;
				}else{
					return false;
				}
			}
		}
		// 효과음온오프 버튼
		class Soundof{
			draw(context){
				if(sound_do == 1)
					context.drawImage(soundOn, 800, 450, 100, 100); // 그리기
				else
					context.drawImage(soundOff, 800, 450, 100, 100); // 그리기
			}
			
			clickSound(xmouse,ymouse){
				if(xmouse > 800 && xmouse < 900 && ymouse > 450 && ymouse < 550){
					console.log('clicked home');
					if(sound_do == 1)
						sound_do = 0;
					else
						sound_do = 1;
					return true;
				}else{
					return false;
				}
			}
		}
		// 맵 그리기
		class Mapdr{
			draw(context){
					context.drawImage(map, 340, 100, 815, 587); // 그리기
			}
			
			clickMap1(xmouse,ymouse){
				if(xmouse > 457 && xmouse < 496 && ymouse > 367 && ymouse < 403){
					map_do = 0;
					map_count = 1;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
			clickMap2(xmouse,ymouse){
				if(xmouse > 694 && xmouse < 728 && ymouse > 308 && ymouse < 343){
					map_do = 0;
					map_count = 2;
					home_do = 1;
					start();
					return true;
				}else{
					return false;
				}
			}
		}
			
      
  		let circle = new Circle();
  		let home1 = new Home1();
  		let home_bar = new Home_bar();
		let musicof = new Musicof();
		let soundof = new Soundof();
		let mapdr = new Mapdr();
		
		function GoMap() {
			clearInterval(intervalId);
  		  mapdr.draw(context);
  		context.drawImage(myair, 460, 370, 30, 30);     // 비행기가 움직이는 대로 다시 그려줌

}