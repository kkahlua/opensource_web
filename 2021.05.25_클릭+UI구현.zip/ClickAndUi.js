canvas.style.background = "#998A00";
      
      var start_do = 0; // 시작했는지 안했는지
      var home_do = 0; // 홈을 눌렀는지 안했는지
      var homebar_do = 0; // 홈 바를 눌렀는지 안했는지
      var music_do = 1; // 배경음악이 들리는가
      var sound_do = 1; // 효과음 들리는가
      
      var musicOn = new Image(); // 배경음악 온 이미지
      musicOn.src = "image/musicOn.png";
      var musicOff = new Image(); // 배경음악 오프 이미지
      musicOff.src = "image/musicOff.png";
      
      var soundOn = new Image(); // 효과음 온 이미지
      soundOn.src = "image/soundOn.png";
      var soundOff = new Image(); // 효과음 오프 이미지
      soundOff.src = "image/soundOff.png";
      
      var home = new Image(); // 홈 이미지
      home.src = "image/home.png";
      
      var play = new Image(); // 플레이 이미지
      play.src = "image/play.png";
      
      var homebar = new Image(); // 홈_바 이미지
      homebar.src = "image/home_bar.png";

      canvas.addEventListener('click', (event) =>{
      	const rect = canvas.getBoundingClientRect();
      	const x = event.clientX - rect.left;
      	const y = event.clientY - rect.top;
      	if(start_do == 0)
      		circle.clickCircle(x,y);
      	if(home_do == 1)
      		home1.clickHome(x,y);
      	if(homebar_do == 1){
      		musicof.clickMusic(x,y);
      		soundof.clickSound(x,y);
      	}
      	console.log('clicked canvas');
      });
      
      function playAudio() {
    	  audioContainer.volume = 0.2;
    	  audioContainer.loop = true;
    	  audioContainer.play();
    	  
    	}

    	function stopAudio() {
    	  audioContainer.pause();  
    	}
    	
    	// 생성자 함수로 Audio 객체 생성
    	function jump_audio() {
    	  var audio = new Audio('jump.mp3');
    	  audio.play();
    	}
    	
      //시작 버튼
		class Circle{
			draw(context){
				context.drawImage(play, 200,300, 200, 100); // 그리기
			}
			
			clickCircle(xmouse,ymouse){
				if(xmouse > 200 && xmouse < 400 && ymouse > 300 && ymouse < 400){
					console.log('clicked play');
					start_do = 1;
					home_do = 1;
					playAudio();
					start();
					return true;
				}else{
					return false;
				}
			}
		}
		
		//홈 버튼 
		class Home1{
			draw(context){
				context.drawImage(home, 0, 0, 50, 50); // 그리기
			}

			clickHome(xmouse,ymouse){
				if(xmouse > 0 && xmouse < 50 && ymouse > 0 && ymouse < 50){
					console.log('clicked home');
					home_do = 1;
					if(homebar_do == 1)
						homebar_do = 0;
					else
						homebar_do = 1;
					return true;
				}else{
					return false;
				}
			}
		}
		
		//홈바 버튼
		class Home_bar{
			draw(context){
				context.drawImage(homebar, 150, 50, 340, 400); // 그리기
				musicof.draw(context);
				soundof.draw(context);
			}
			
			clickHome(xmouse,ymouse){
				if(xmouse > 0 && xmouse < 50 && ymouse > 0 && ymouse < 50){
					console.log('clicked home');
					home_bar = 1;
					return true;
				}else{
					return false;
				}
			}
		}
		//배경음악온오프 버튼
		class Musicof{
			draw(context){
				if(music_do == 1)
					context.drawImage(musicOn, 250, 250, 50, 50); // 그리기
				else
					context.drawImage(musicOff, 250, 250, 50, 50); // 그리기
			}
			
			clickMusic(xmouse,ymouse){
				if(xmouse > 250 && xmouse < 300 && ymouse > 250 && ymouse < 300){
					console.log('clicked home');
					if(music_do == 1){
						stopAudio();
						music_do = 0;
					}else{
						playAudio();
						music_do = 1;
					}
					return true;
				}else{
					return false;
				}
			}
		}
		//효과음온오프 버튼
		class Soundof{
			draw(context){
				if(sound_do == 1)
					context.drawImage(soundOn, 350, 250, 50, 50); // 그리기
				else
					context.drawImage(soundOff, 350, 250, 50, 50); // 그리기
			}
			
			clickSound(xmouse,ymouse){
				if(xmouse > 350 && xmouse < 400 && ymouse > 250 && ymouse < 300){
					console.log('clicked home');
					if(sound_do == 1)
						sound_do = 0;
					else
						sound_do = 1;
					return true;
				}else{
					return false;
				}
			}
		}
      
  		let circle = new Circle();
  		let home1 = new Home1();
  		let home_bar = new Home_bar();
		let musicof = new Musicof();
		let soundof = new Soundof();