
      
      /*back-ground*/
      var back0 = new Image();        //back-ground Image
      back0.src = "image/background.png";
      
      var backcount = 0;              //back-ground Image Index
      var backgroundX = 1500;      //back-ground X 
      var backgroundY = 800;      //back-ground y 
     
     
    
      /* 변수 선언 */ 
	
      /*---------------------------------------족제비------------------------------------------------- */
      var myair = new Image();    //비행기 이미지
      myair.src = "image/testobj2.png";
      var startX = 640 / 2 - 15;      //비행기 초기 위치
      var startY = 600;        //비행기 초기 위치
      
      //위치
      var myairX = startX;     //비행기 x
      var myairY = startY;     //비행기 y
      //이동속도
      var myspeedX=0;
      var myspeedY=0;
      
      
      //obj 크기값
      var my0sizeX=40;
      var my0sizeY=40;
      
      
      //가능상태
      var canleft =0;
      var canright=0;
      var canup =0;
      var canrdown=0;
      var canjump=0;
      var golemup=false;
      
      var moveSpeed = 10;       //비행기 이동속도크기
      
     
      
      var jumpspeed=10;//점프속도
      
      var gravity=0.1;//중력값
      
      var leftkey = false;    //왼쪽키눌림
      var rightkey = false;   //오른쪽키눌림
      var upkey = false;      //위키눌림
      var downkey = false;    //아래키눌림
      var spacebar=false;     //스페이스바인식

      /*----------------------------------------골램---------------------------------------------------*/
      /*골램 이미지 설정*/
      var golemwait = new Array();
      for(var i = 1; i <= 7; i++){
    	  golemwait[i-1] = new Image();
    	  golemwait[i-1].src = "image/golem/golem wait_" + i + ".png";
      }
      var golemwalk = new Array();
      for(var i = 1; i <= 8; i++){
    	  golemwalk[i-1] = new Image();
    	  golemwalk[i-1].src = "image/golem/golem walk_" + i + ".png";
      }
      var golemwalkarm = new Array();
      for(var i = 1; i <= 8; i++){
    	  golemwalkarm[i-1] = new Image();
    	  golemwalkarm[i-1].src = "image/golem/arm/golem walk_arm_" + i + ".png";
      }
      
      /*이미지 프레임 딜레이*/
      var framedelayset=20;//정지 딜레이
      var framedelayset2=18;//이동 딜레이
      var framedelay=0;
      var frame=0;
      var framewalk=0;//걸을때 프레임 프레임 공유하면 프레임수가 달라서 프레임끼리 꼬임
      var flip=false;//이미지 뒤집힘 확인
      
      var golemsizeX=120;//충돌 판정크기
      var golemsizeY=120;
      
      var golemimagesizeX=160;//이미지 크기
      var golemimagesizeY=160;
      var golemimagesX=-25;//이미지 좌표조정
      var golemimagesXr=7;//반전 이미지좌표 조정
      var golemimagesY=-20;
      
      var golemX=0;//위치값
      var golemY=600;
     
      var golemspeedY=0;
      var golemSpeed = 2;//이동속도    
      var golemspeedX=2;
      
      var golemcanleft =0;//오브젝트 충돌판정
      var golemcanright=0;
	  var golemelevator = 0;//엘베 속도 받아옴
      
      var akey = false;    //왼쪽키눌림
      var dkey = false;   //오른쪽키눌림
      var wkey = false;      //위키눌림
      var skey = false;    //아래키눌림
      
      
      /*---------------------위 골램--------------------------*/
      

      /*------------------------------충돌 가능 오브젝트-------------------------- */
      
      var enemy1 = new Image();
      enemy1.src = "image/black2.png";
      var enemyList = [];
      //블럭 크기
      var black0sizeX=50;
      var black0sizeY=50;
      
      var enemy2 = new Image();
      enemy2.src = "image/testobj.png";//반투과 플렛폼
      var enemy2List = [];
   	  //블럭 크기
      var black1sizeX=150;
      var black1sizeY=5;
      /*------------------------------게이트-------------------------- */
      var gate = new Image();
      gate.src = "image/gate.png";
      
      //블럭 크기
      var gateinX=0;
      var gateinY=0;
      var gatesizeX=300;
      var gatesizeY=300;
      
      /*------------------------------큐브-------------------------- */
      var cube = new Image();
      cube.src = "image/cube.png";
      var cubeL = new Image();
      cubeL.src = "image/cubeL.png";
      
      //블럭 크기
      var cubeList = [];

      var cubesizeX=150;
      var cubesizeY=150;
      
     
      
      var cubeimagesizeX=170;
      var cubeimagesizeY=170;
      
      /*--------------------------엘리베이터----------------------------*/
      var elevator = new Image();
      elevator.src = "image/elevator1.png";//엘리베이터
      var elevator2 = new Image();
      elevator2.src = "image/elevator2.png";//작동
      var elevatorL = new Image();
      elevatorL.src = "image/elevatorL.png";//효과1
      var elevatorL2 = new Image();
      elevatorL2.src = "image/elevatorL2.png";//효과2
      
      var elevatorL2frame =1;//효과2 프레임
      
      var elevatorList = [];
      //실제판정
      var elevatorsizeX=150;
      var elevatorsizeY=750;
      //이미지
      var elevatorimagesizeX=180;
      var elevatorimagesizeY=750;
      
      var elevatorspeedY=3;//엘리베이터 이동속도
     
	  /*--------------------------버튼------------------------------*/
	  
     //업버튼
	  var buttonup = new Image();
      buttonup.src = "image/buttonup.png";
      var buttonupList = [];
  
      //다운버튼
      var buttondown = new Image();
      buttondown.src = "image/buttondown.png";
      var buttondownList = [];
      
      //버튼 불빛
      var buttonL = new Image();
      buttonL.src = "image/buttonL.png";
      
      //버튼 이펙트
      var buttonL2 = new Image();
      buttonL2.src = "image/buttonL2.png";
    	
      //버튼 이펙트2
      var buttonL3 = new Image();
      buttonL3.src = "image/buttonL3.png";
      
      var angle=0;//장식 회전 효과
      
    //실제판정
	  var buttonsizeX=100;
      var buttonsizeY=100;
      
    //이미지  크기
      var buttonimagesizeX=150;
      var buttonimagesizeY=150;
	  
      /*--------------------------장식------------------------------*/
      var sod00 = new Image();
      sod00.src = "image/sod00.png";
      var sod0 = new Image();
      sod0.src = "image/sod0.png";
      var sod1 = new Image();
      sod1.src = "image/sod1.png";
      var backgroundL = new Image();        //back-ground Image
      backgroundL.src = "image/backgroundL.png";