var canvas = document.getElementById("myCanvas");		// 컨버스 가져와서 작업 시작
      var context = canvas.getContext("2d");				// 2D를 드로잉 컨텍스트에 엑세스
      

     
      
    /* 초기화 */
      function init() {
      
          myairX = startX;
          myairY = startY;
    
          circle.draw(context);
      }

      function draw() {      // 캔버스에 그리기
    	 
          drawBackground();// 벡그라운드
          
          //미사일 버튼
          drawmissilebutton();
          //철
          drawiron();
          
          
          
          // 충돌판정
          drawEnemy();
          // 이동판정
          moveweasel();
          
          // 오브젝트뒤
          context.drawImage(sod1, -100, backgroundY-75, backgroundX/2, 100);// 땅그리기
		  context.drawImage(sod1, backgroundX/2-300, backgroundY-75, backgroundX/2, 100);// 땅그리기
		  context.drawImage(sod1, backgroundX/2+100, backgroundY-75, backgroundX/2, 100);// 땅그리기
		  context.drawImage(sod0, -100, backgroundY-75, backgroundX/2, 100);// 땅그리기
		  context.drawImage(sod0, backgroundX/2-300, backgroundY-75, backgroundX/2, 100);// 땅그리기
		  context.drawImage(sod0, backgroundX/2+100, backgroundY-75, backgroundX/2, 100);// 땅그리기
		  
          /*------------------추가부분-------------------------*/
   	   	  drawDoor();
          if(check)
          {
           drawLock();
         }
          
          /*---------------위 추가부분-------------------------*/
          
          // 오브젝트 앞
          context.drawImage(sod00, -100, backgroundY-75, backgroundX/2, 100);// 땅그리기
		  context.drawImage(sod00, backgroundX/2-300, backgroundY-75, backgroundX/2, 100);// 땅그리기
		  context.drawImage(sod00, backgroundX/2+100, backgroundY-75, backgroundX/2, 100);// 땅그리기
		  // 이동캐릭터
          drawgolem();
          
		  context.drawImage(myair, myairX, myairY, my0sizeX, my0sizeY);// 족제비
																		// 그림 큐브
																		// 물리연산
																		// 끝난 뒤에
																		// 그려줘야
																		// 이동이
																		// 자연스러움
		  // 오브젝트 효과 이펙트
		  drawlight();
		  context.drawImage(backgroundL, 0, 0, 1500, 800);// 맵빛효과
		  
	  		home1.draw(context);
	  		drawMissile();
	  		if(homebar_do == 1)
	  			home_bar.draw(context); // ///////////////////////////// 바꿈
		 
		 
		 
  
      }
      
      /*
		 * <-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<전체
		 * 오브젝트 생성>->->->->->->->->->->->->->->->->->->->->->->->->->
		 */
      
      function makeAllEnemy() {// 오브젝트 생성
    	  
    	  
    	  makeEnemy(450,300);
    	  makeEnemy(500,300);
    	  makebuttonup(800,backgroundY-150);
    	  makebuttondown(1100,backgroundY-150);
    	  makeelevator(200,backgroundY-50,450);
    	  makecube(400,backgroundY-200);
    	  makegatein(0,backgroundY-350);
    	  for(var i = 0; i < backgroundX/50; i++){
    		  makeEnemy(i*50,backgroundY-50);
    	  }
    	  makeDoor(1400,100);
    	  makeLock(1400,100);
    	
    		  
         

      }

     
      // 이동은 위쪽
/*------------------------배경--------------------------*/
      function drawBackground() {      // 배경 그리기
          context.drawImage(back0, 0, 0, 1500, 800);
          
      }
   


      
    /* 키누르기 */
  
    
      document.addEventListener("keydown", onkey_press, false);
      document.addEventListener("keyup", onkey_up, false);
      
      function onkey_press() {      // 키눌렀을때
    	  /*-------------------족제비-----------------*/
          if (event.keyCode == 37) {    // 왼쪽이동
              leftkey = true;
          }
          else if (event.keyCode == 39) {    // 오른쪽이동
              rightkey = true;
          }
          else if (event.keyCode == 38) {    // 위쪽이동
              upkey = true;
          }
          else if (event.keyCode == 40) {    // 아래쪽이동
              downkey = true;
          }
          if (event.keyCode == 32) {    // 스페이스바 점프
        	  spacebar = true;
        	  if(canjump>0)// 점프 가능 상태 확인
          	  	jump_audio();
          }
          
          /*---------------멥이동------------------*/
          
          if (event.keyCode == 90) {       // z키눌러서 맵 이동 ㅇㅇ?
              keypress = true;
            }
          
          /*-----------------골램----------------*/
          
          if (event.keyCode == 65) {    // a누름
        	  akey = true;
          }
          else if (event.keyCode == 68) {    // d누름
        	  dkey = true;
          }
          else if (event.keyCode == 87) {    // w누름
        	  wkey = true;
        	 
          }
          else if (event.keyCode == 83) {    // s누름
        	  skey = true;
        	 
          }
          
      }
      
      function onkey_up() {      // 키땠을때
    	  
    	  /*-------------------족제비-----------------*/
          if (event.keyCode == 37) {    // x이동
              leftkey = false;
          }
          else if (event.keyCode == 39) {    // x이동
              rightkey = false;
          }
          if (event.keyCode == 38) {    // y이동
              upkey = false;
          }
          else if (event.keyCode == 40) {    // y이동
              downkey = false;
          }

          if (event.keyCode == 32) {    // 스페이스바 점프
        	  spacebar = false;
          }
          /*---------------멥이동------------------*/
          if (event.keyCode == 90) {     // z키눌러서 맵 이동 ㅇㅇ?
              keypress = false;
            }
          
          /*-----------------골램----------------*/
          
          if (event.keyCode == 65) {    // a누름
        	  akey = false;
          }
          else if (event.keyCode == 68) {    // d누름
        	  dkey = false;
          }
          else if (event.keyCode == 87) {    // w누름
        	  wkey = false;
          }
          else if (event.keyCode == 83) {    // s누름
        	  skey = false;
          }
      }
      
      
     /*-----------------------멥판정------------------------------------*/
  
     
	 
      var intervalId;
     /*----------------------------------------------------------매인---------------------------------------------------------------*/  
   
     function start() {	// start 버튼 클릭시 이벤트
          init();			// 초기 설정
          intervalId = clearInterval();  // 설정 초기화
          makeAllEnemy();
          document.getElementById("start").style.visibility = "hidden";		// start
																			// 버튼
																			// 감추기
          switch(map_count){ // ㅇ?
          case 1:
       	   map1();
       	   break;
          case 2:
       	   map2();
       	   break;
          case 3:
       	   map3();
       	   break;
          case 4:
          		map4();
          		break;
          default:
       	   break;
        }
          intervalId = setInterval(function () {  // js 주기적 실행 옵션 0.01 초마다 실행
              checkMissile();
        	  makeMissile();        // 미사일 생성
              moveMissile();        // 미사일 이동 ///////////바꿈
              removeMissile();      // 미사일 제거
        	  golemmove();
        	  draw();                // 개체 그리기
        	  missileDelay--;

              
         
          }, 10);
      }