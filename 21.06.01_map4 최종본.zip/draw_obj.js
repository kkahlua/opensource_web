 /*---------------------------------------------------<비>충돌 오브젝트 그리기---------------------------------------------------*/
      
       function drawbuttonup() {//업버튼
          for (var i = 0; i < buttonupList.length; i++) {
              var tmp = buttonupList[i];
              var tmp2 = elevatorList[i];//엘리베이터와 연결
              context.drawImage(enemy2, tmp.x, tmp.y, buttonsizeX,buttonsizeX);
              context.drawImage(buttonup, tmp.x-25, tmp.y, buttonimagesizeX,buttonimagesizeY);
              if(myairX < tmp.x + buttonsizeX && myairX > tmp.x - (my0sizeX) && myairY < tmp.y + buttonsizeX && myairY > tmp.y - my0sizeY)
            	  {//족제비와 충돌시 작동
                  context.drawImage(buttonL, tmp.x-25, tmp.y, buttonimagesizeX,buttonimagesizeY);
                 
                  tmp2.up=true;
              }
              else{
            	   tmp2.up=false;
              }
              
              
          }

      }
       function drawbuttondown() {//다운 버튼
           for (var i = 0; i < buttondownList.length; i++) {
               var tmp = buttondownList[i];
               var tmp2 = elevatorList[i];//엘리베이터와 연결
               context.drawImage(enemy2, tmp.x, tmp.y, buttonsizeX,buttonsizeX);
               context.drawImage(buttondown, tmp.x-25, tmp.y, buttonimagesizeX,buttonimagesizeY);
               if(myairX < tmp.x + buttonsizeX && myairX > tmp.x - (my0sizeX) && myairY < tmp.y + buttonsizeX && myairY > tmp.y - my0sizeY)
             	  {//족제비와 충돌시 작동
                   context.drawImage(buttonL, tmp.x-25, tmp.y, buttonimagesizeX,buttonimagesizeY);
                  
                   tmp2.down=true;
               }
               else{
             	   tmp2.down=false;
               }
               
               
           }

       }
       function drawgate() {//시작게이트
          
               context.drawImage(gate, gateinX, gateinY, gatesizeX, gatesizeY);
      
       }
      
      /*---------------------------------------충돌 오브젝트 그리기---------------------------------------------------*/
      
      function drawEnemy() {//충돌 판정 그리기
          for (var i = 0; i < enemyList.length; i++) {
              var tmp = enemyList[i];
              //족제비 좌우 충돌 쓰일 일이 있을지는 모르겠음.
            	if(myairX < tmp.x + black0sizeX && myairX > tmp.x - (my0sizeX) && myairY < tmp.y + black0sizeY && myairY > tmp.y - my0sizeY+5){
            		//5정도는 떨어트려놔야 위쪽에 있을때 반응안함
        			if(myairX < tmp.x + black0sizeX/2-(my0sizeX)/2){
        				myairX=tmp.x - (my0sizeX)
        			}
        			else{
        				
        				myairX=tmp.x + black0sizeX
        			}
        			if(myairY < tmp.y + black0sizeX/2-(my0sizeY)/2){
        			}

        		}
     
            
              context.drawImage(enemy1, tmp.x, tmp.y, black0sizeX, black0sizeY);
          }

      }
      
      /*---------------------------------------플렛폼 오브젝트 그리기+연산---------------------------------------------------*/
      

      function drawEnemy2(){//플렛폼 그리기 
    	  for (var i = 0; i < enemy2List.length; i++) {
              var tmp2 = enemy2List[i];
              var tmp4 = elevatorList[i];
              tmp2.x=tmp4.x
              tmp2.y=tmp4.y
              context.drawImage(enemy2, tmp2.x, tmp2.y, black1sizeX, black1sizeY);
          }
      } 


/*---------------------------------------------큐브 그리기---------------------------------------------------*/
      
      function drawcube(){//큐브 그리기 
    	  for (var i = 0; i < cubeList.length; i++) {
              var tmp = cubeList[i];
             
             if(tmp.speedx==0){
            	 context.drawImage(cube, tmp.x-10, tmp.y-10, cubeimagesizeX, cubeimagesizeY);
             }else{
            	 context.drawImage(cubeL, tmp.x-10, tmp.y-10, cubeimagesizeX, cubeimagesizeY);
             }
             
          }
      }
      
      /*---------------------------------------엘리베이터 오브젝트 그리기+연산---------------------------------------------------*/
      
      function drawelevator() {//엘베그리기
          for (var i = 0; i < elevatorList.length; i++) {
              var tmp3 = elevatorList[i];
          
              if(tmp3.down==true){//하강
            	
            	 if(tmp3.y<=tmp3.limitstartY){
            	 	tmp3.speedy=elevatorspeedY;//속도계산
            	 	tmp3.y+=tmp3.speedy//속도로 이동
            	 	  context.drawImage(elevator2, tmp3.x-20, tmp3.y-20, elevatorimagesizeX, elevatorimagesizeY);
            	 	for (var i = 0; i < tmp3.objList.length; i++) {//자신 위치의 충돌판정을 이동시킴
                    	 var tmp5 = enemyList[tmp3.objList[i]];
                     	tmp5.y+=elevatorspeedY//이동
                     	
            	 	}
            	 	
            	 }else{
            		 tmp3.speedy=0;//한계 정지
            		  context.drawImage(elevator2, tmp3.x-20, tmp3.y-20, elevatorimagesizeX, elevatorimagesizeY);
            	 }
            	 
            	}else if(tmp3.up==true){//상승
            		
            		if(tmp3.y>=tmp3.limitendY){
            	 		tmp3.speedy=-elevatorspeedY;//속도계산
            	 		tmp3.y+=tmp3.speedy//속도로 이동
            	 		  context.drawImage(elevator2, tmp3.x-20, tmp3.y-20, elevatorimagesizeX, elevatorimagesizeY);
            	 		for (var i = 0; i < tmp3.objList.length; i++) {
                     		var tmp5 = enemyList[tmp3.objList[i]];
                     		tmp5.y-=elevatorspeedY//이동
                     		
            	 	}
            	 		
            	 }else{
            		 tmp3.speedy=0;//한계 정지
            		  context.drawImage(elevator2, tmp3.x-20, tmp3.y-20, elevatorimagesizeX, elevatorimagesizeY);
            	 }
        	  	}else{
        	  	tmp3.speedy=0;//미작동 정지
        	    context.drawImage(elevator, tmp3.x-20, tmp3.y-20, elevatorimagesizeX, elevatorimagesizeY);
        	  	 
        	  	}
             
              
              
            
          }

      }
      
    /*----------------------------------------------------골램 그리기----------------------------------------------------------------------------------------*/
      
      
      function drawgolem(){
    	  if(akey==false&&dkey==false){//정지상태
    		  framewalk=0;//초기화 안해주면 동작중간부터 시작함
    		if(flip==false){//정상상태
    	  		context.drawImage(golemwait[frame], golemX+golemimagesX, golemY+golemimagesY, golemimagesizeX, golemimagesizeY);
    		}else{//뒤집기 상태
    			context.scale(-1, 1);//뒤집음
    			context.drawImage(golemwait[frame], -golemX+golemimagesXr, golemY+golemimagesY, -golemimagesizeX, golemimagesizeY);
    			context.scale(-1, 1);//뒤집은거 복원 안하면 난리남
    		}
    	  	if(framedelay==0){
    			  frame++;
    		  	framedelay=framedelayset;
    	  	}else{
    			  framedelay--;
    		  }
    	  
          	if(frame==6){
            	  frame=0;
          	}
    	  }else{//a나d키를 누름 이동모션
    		  frame=0;//초기화 안해주면 동작중간부터 시작함
    		if(akey==true){//왼쪽이동 이미지 반전
    	   		context.scale(-1, 1);//뒤집음
    			context.drawImage(golemwalk[framewalk], -golemX+golemimagesXr, golemY+golemimagesY, -golemimagesizeX, golemimagesizeY);//골램    		
    			context.drawImage(golemwalkarm[framewalk], -golemX+golemimagesXr, golemY+golemimagesY, -golemimagesizeX, golemimagesizeY);//골램팔
    			context.scale(-1, 1);//뒤집은거 복원 안하면 난리남
    			flip=true;//뒤집기참
    		}else{
    			context.drawImage(golemwalk[framewalk], golemX+golemimagesX, golemY+golemimagesY, golemimagesizeX, golemimagesizeY);    		
        		context.drawImage(golemwalkarm[framewalk], golemX+golemimagesX, golemY+golemimagesY, golemimagesizeX, golemimagesizeY);
        		flip=false;
        		
    		}
    		if(framedelay==0){
    			framewalk++;
  		  		framedelay=framedelayset2;
  	  		}else{
  				framedelay--;
  		    }
  	  
        	if(framewalk==7){
        		framewalk=0;
        	}
    	  }	  
            
     /*----------------------------------------------------------빛 효과 그리기---------------------------------------------------------------*/              
         
      }
      function drawlight(){//빛 그리기
    	  for (var i = 0; i < elevatorList.length; i++) {
              var tmp3 = elevatorList[i];
              var tmp2 = buttonupList[i];
              var tmp1 = buttondownList[i];
              
            	
            	if(tmp3.down==true){
            		context.drawImage(elevatorL2, tmp3.x-20, tmp3.y-elevatorL2frame/20*elevatorimagesizeY, elevatorimagesizeX, elevatorimagesizeY+elevatorL2frame);
            		
            		//context.drawImage(buttonL2, tmp1.x-25, tmp1.y, 150, 150);
            		
            	
                  	context.drawImage(buttonL2, tmp1.x-25, tmp1.y, 150, 150);
                  	
            		elevatorL2frame--;
                	if(elevatorL2frame<=0){
                		elevatorL2frame=20;
                		
                	}
                	
            	}else if(tmp3.up==true){
            		
            		context.drawImage(elevatorL2, tmp3.x-20, tmp3.y-elevatorL2frame/20*elevatorimagesizeY, elevatorimagesizeX, elevatorimagesizeY+elevatorL2frame);
            		
            		//context.drawImage(buttonL2, tmp2.x-25, tmp2.y, 150, 150);
            		
        			context.drawImage(buttonL2, tmp2.x-25, tmp2.y, 150, 150);
                  	
            		elevatorL2frame++;
                	if(elevatorL2frame>=20){
                		elevatorL2frame=1;
                		
                	}
                	
            	
            	}
            	
              
    	  }
      }
      