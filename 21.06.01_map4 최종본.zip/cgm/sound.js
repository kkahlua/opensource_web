var musicOn = new Image(); // 배경음악 온 이미지
musicOn.src = "image/musicOn.png";
var musicOff = new Image(); // 배경음악 오프 이미지
musicOff.src = "image/musicOff.png";

var soundOn = new Image(); // 효과음 온 이미지
soundOn.src = "image/soundOn.png";
var soundOff = new Image(); // 효과음 오프 이미지
soundOff.src = "image/soundOff.png";

function playAudio() {
	audioContainer.volume = 0.2;
	audioContainer.loop = true;
	audioContainer.play();

}

function stopAudio() {
	audioContainer.pause();
}

// 생성자 함수로 Audio 객체 생성
function jump_audio() {
	var audio = new Audio('sound/jump.mp3');
	audio.play();
}

function lazer_audio() {
	var audio = new Audio('sound/lazer.mp3');
	audio.play();
}