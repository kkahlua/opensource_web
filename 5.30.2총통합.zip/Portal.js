var R_portal = new Image();
R_portal.src = "image/R_portal.png";
var Rp_frame=0;
var Rp_maxFrame=8;
var L_portal = new Image();
L_portal.src = "image/L_portal.png";
var Lp_frame=0;
var Lp_maxFrame=8;

function drawR_portalMotionM1(){
    context.drawImage(R_portal, Rp_frame % 4, Math.floor(Rp_frame / 4),
                               70, 70, 50, 450, 200, 200);
    Rp_frame = (Rp_frame + 0.1)% Rp_maxFrame;
}


function drawL_portalMotionM1(){
    context.drawImage(L_portal, Lp_frame % 4, Math.floor(Lp_frame / 4),
                               70, 70, 1100, 300, 200, 200);
    Lp_frame = (Lp_frame + 0.1)% Lp_maxFrame;
}

