/*--------------------------------족제비 이동----------------------------------------*/
      
      function moveweasel() {  //족제비 이동계산
    	  
    	 //y축 계산
		  if (myairY < backgroundY-my0sizeY) {  //멥 바닥에 닿았는지 확인
		  	myspeedY +=gravity;//중력 가속도 계산
              
          }else{//멥 바닥에 닿음 
        	  myspeedY=0//탈출 속도제어
        	  canjump=1//점프 초기화
          }
      
			//점프
          if (spacebar == true) {	// 스페이스 키가 눌렸을 때 
        	  if(canjump>0){//점프 가능 상태 확인
        		myspeedY -= jumpspeed;//점프 속도부여
        		canjump -= 1;//점프 -1
               }
          }
          /*-----------------------------멥 이동----------------------------------*/
          if (keypress == true){ // 멥 이동 좌표판정
              if(myairX>=1400&&myairX<=1450&&myairY<=150&&myairY>=75)
              {
                if(!check)
                {
                  count=2;
                }
              }
            }
          /*---------------------------------------------------------------*/
			
      	//상승 하강시 오브젝트 충돌 해당방향 이동정지 판단
          if(myspeedY<0){//상승
         	 canup=0;
    		  for (var i = 0; i < enemyList.length; i++) {  // 머리충돌판정
          	    var tar = enemyList[i];
          	      if (myairY < +myspeedY){//맵 판정
          	    	myairY=0;
          	    	myspeedY=0;
          	      }else if(myairX < tar.x + black0sizeX-5 && myairX > tar.x - (my0sizeX)+5 && myairY < tar.y + black0sizeY-myspeedY && myairY > tar.y - my0sizeY){
          	    	//충돌판정에 이동방향에 속도 값 방향 생각해서 넣으면 됨 +-5는 옆에서 충돌판정 나기전에 날아가는거 방지
          	    	canup+=1
    	 	 		myspeedY=0;//속도0로 변경
    	 	 		myairY = tar.y + black0sizeY;//위치 상세조정
    		  	  }
    		  }
          }
          if(myspeedY>0){//하강
        	  canrdown=0;
     		  for (var i = 0; i < enemyList.length; i++) {  // 발충돌판정
           	    var tar = enemyList[i];
               
     	 	 	  if(myairX < tar.x + black0sizeX-5 && myairX > tar.x - (my0sizeX)+5 && myairY < tar.y + black0sizeY && myairY > tar.y - my0sizeY-myspeedY){
     	 	 		//+-5는 옆에서 충돌판정 나기전에 날아가는거 방지
     	 	 		canrdown+=1
     	 	 		myspeedY=0;
     	 	 		myairY = tar.y  -my0sizeY;
     	 	 		canjump=1//오브젝트 착지시 점프판단
     		  	  }
     		  }
     		  
            	
     		// 골램상충돌판정
     		
      	 	 	  if(myairX < golemX + golemsizeX && myairX > golemX - (my0sizeX) && myairY < golemY- my0sizeY+5 && myairY > golemY - my0sizeY-1-myspeedY-golemspeedY-golemelevator){
      	 	 		canrdown+=1//- my0sizeY+5수직거리 충돌 판단, -1와 golemspeedY은 내려갈때 통통거림방지 golemelevator골램 엘베 탑승 확인
      	 	 		golemup=true;
      	 	 		myspeedY=0;
      	 	 		myairY = golemY -my0sizeY;
      	 	 		canjump=1//오브젝트 착지시 점프판단
      	 	 		
      	 	 		if (akey == true){//골램하고 같이 이동하는 판단
      	 	 	  		if(golemcanright==0){
      	 	 	  			myairX -= golemSpeed;
          	 				}     	
      	 	 	  		}
      		  	 	 
      	 	 	 	 if (dkey == true){
      	 	 	  		if(golemcanleft==0){
      	 	 	  	  	  myairX += golemSpeed;
          	 				}     	
      	 	 		  	}
      	 	 		
      		  	  }else{
      		  		golemup=false;
      		  	  }
      		  
     		 for (var i = 0; i < enemy2List.length; i++) {  // 발판충돌판정
         	    var tar = enemy2List[i];
         	    var tar2 = elevatorList[i];//속도값 호출용
             
   	 	 	  if(myairX < tar.x + black1sizeX && myairX > tar.x - (my0sizeX) && myairY < tar.y && myairY > tar.y - my0sizeY-myspeedY-1-tar2.speedy){
   	 	 		  //-1-tar2.speedy 하강시 튕김 방지
   	 	 		  canrdown+=1
   	 	 		  myspeedY=0;
   	 	 		  myairY = tar.y  -my0sizeY;
   	 	 		  canjump=1//오브젝트 착지시 점프판단
   	 	 
   	 	 		
   		  	 		}
   		  		}
           }
          
			
          myairY += myspeedY;//y축 속도로 위치변경
          
          //Y축 위치계산 후 X축 계산이 들어가야함 안그러면 x축 계산 if문에서 y속도 계산해줘야함 안그러면 속도가 빠를경우 대각선 이동시 오브젝트 통과할 수 있음 X Y축 따로 계산이 정신 건강에 이로움
          //현제 이동 오차가 조금 있는데 프레임당 이동거리가 짧아서 오차가 무시 가능한 수준

    	  //x축 계산
    	  
    	  //좌우 이동시 오브젝트 충돌 해당방향 이동정지 판단
    	  
          if (leftkey == true) {		// 왼쪽 키가 눌렸을 때 
              if (myairX > 0) { //멥판정
            	 
            		  canright=0;
                	  for (var i = 0; i < enemyList.length; i++) {  // 우충돌판정
                          var tar = enemyList[i];
                          
                	  	  if(myairX < tar.x + black0sizeX+moveSpeed && myairX > tar.x -my0sizeX && myairY < tar.y + black0sizeY && myairY > tar.y - my0sizeY){
                	  		canright+=1//충돌판정에 이동방향에 속도 값 방향 생각해서 넣으면 됨 변수값이 양수인지 음수인지 생각해서 넣어야됨
                	  		
                	  		//myairX = tar.x + black0sizeX;//이동가능한 최대 위치로 이동;
                	  		
                	  	  }
                	  }
                	  if(canright==0){
                	  	myairX -= moveSpeed;
                	  }     	 
                  
              }
          }
          else if (rightkey == true) {  // 오른쪽 키가 눌렸을 때 
              if (myairX < backgroundX-my0sizeX) { //멥판정
            	  canleft=0;
            	  for (var i = 0; i < enemyList.length; i++) {  // 좌충돌판정
                      var tar = enemyList[i];
                      
            	  	  if(myairX < tar.x + black0sizeX && myairX > tar.x -my0sizeX-moveSpeed && myairY < tar.y + black0sizeY && myairY > tar.y -my0sizeY){
            	  		canleft+=1
            	  	
            	  		//myairX = tar.x -my0sizeX;//이동가능한 최대 위치로 이동;
            	  	  }
            	  }
            	  if(canleft==0){
            	  	myairX += moveSpeed;
            	  }     	 
              }
          }
          
/*-----------------------------텔레포트-----------------------------------*/
          //아래 if문 2개 함수로 바꿔야댐 ㅇㅇ? 좌표식
          if(myairX<=100&&myairX>=75&&myairY<=600&&myairY>=550)
          {

            myairX=1100;
            myairY=400
          }

          if(myairX==1200&&myairX>=1175&&myairY<=450&&myairY>=400)
          {
            myairX=100;
            myairY=550
          }
          
          if(myairX<=1400&&myairX>=1300&&myairY<=350&&myairY>=300)//코인
          {
            check=false;
            getCoin=true;
          }
         
     }
      /*---------------------------------------------------------------*/  
      
      /*--------------------------------------------------------------골램이동---------------------------------------------------*/
      
      function golemmove() {  // 골램 위치잡기
    	  
    	 //y축 계산
		  if (golemY < backgroundY-golemsizeY) {  //멥 바닥 판정 확인 지금은 공중상태
			  golemspeedY +=gravity;//중력 가속도 계산
              
          }else{//멥 바닥에 닿음 
        	  golemspeedY=0//탈출 속도제어
        	  
          }
      
	
			
			
      	//상승 하강시 오브젝트 충돌 해당방향 이동정지 판단
          if(golemspeedY<0){//상승
         	
    		  for (var i = 0; i < enemyList.length; i++) {  // 우충돌판정
          	    var tar = enemyList[i];
          	      if (myairY < +golemspeedY){//맵 판정
          	    	golemY=0;
          	    	golemspeedY=0;
          	      }else if(golemX < tar.x + black0sizeX && golemX > tar.x - (golemsizeX) && golemY < tar.y + black0sizeY-golemspeedY && golemY > tar.y - golemsizeY){
    	 	 	
    	 	 		golemspeedY=0;//속도0로 변경
    	 	 		golemY = tar.y + black0sizeY;//위치 상세조정
    		  	  }
    		  }
          }
          if(golemspeedY>0){//하강
        	
     		  for (var i = 0; i < enemyList.length; i++) {  // 우충돌판정
           	    var tar = enemyList[i];
               
     	 	 	  if(golemX < tar.x + black0sizeX && golemX > tar.x - (golemsizeX) && golemY < tar.y + black0sizeY && golemY > tar.y - golemsizeY-golemspeedY){
     	 	 		
     	 	 		golemspeedY=0;
     	 	 		golemY = tar.y  -golemsizeY;
     	 	 		
     	 	 	
     		  	  }
     		  }
     	
           }
          for (var i = 0; i < enemy2List.length; i++) {  // 발판충돌판정
       	    var tar = enemy2List[i];
       	 	var tar2 = elevatorList[i];//속도값 호출용
           
 	 	 	  if(golemX < tar.x + black1sizeX && golemX > tar.x - (golemsizeX) && golemY < tar.y&& golemY > tar.y - golemsizeY-golemspeedY-1-tar2.speedy){
 	 	 		  //-1-tar2.speedy 하강시 튕김 방지
 	 	 		  golemspeedY=0;
 	 	 		  golemY = tar.y  -golemsizeY;
 	 	 		  golemY = tar.y  -golemsizeY;
 	 	 		  golemelevator=tar2.speedy;
 	 	 		  if(golemup==true){
 	 	 			 if(myspeedY==0){//이 조건 안 넣어주면 점프 안 먹힘
 	 	 				 myairY = golemY -my0sizeY;
 	 	 				 }
 	 	 			
 	 	 		  }
 	 	 		
 		  	 		}else{
 		  	 		golemelevator=0;
 		  	 		}
 		  		}
          
			
          golemY += golemspeedY;//y축 속도로 위치변경
          
          //Y축 위치계산 후 X축 계산이 들어가야함 안그러면 x축 계산 if문에서 y속도 계산해줘야함 안그러면 속도가 빠를경우 대각선 이동시 오브젝트 통과할 수 있음 X Y축 따로 계산
          

    	  //x축 계산
    	  
    	 
    	  
    	  //좌우 이동시 오브젝트 충돌 해당방향 이동정지 판단
    	  
          if (akey == true) {		// 왼쪽 키가 눌렸을 때 
              if (golemX > 0) { //멥판정
            	 
            	  		golemcanright=0;
                	  for (var i = 0; i < enemyList.length; i++) {  // 우충돌판정
                          var tar = enemyList[i];
                          
                          if(golemX < tar.x + black0sizeX+golemSpeed && golemX > tar.x -golemsizeX && golemY < tar.y + black0sizeY && golemY > tar.y - golemsizeY){
                	  		golemcanright+=1//충돌판정에 이동방향에 속도 값 방향 생각해서 넣으면 됨 변수값이 양수인지 음수인지 생각해서 넣어야됨
                	  		
                	  		golemX = tar.x + black0sizeX;//이동가능한 최대 위치로 이동;
                	  		
                	  	  }
                	  }
                	  if(golemcanright==0){
                		  golemX -= golemSpeed;
                	  }     	 
                  
              }else{
            	  golemcanright+=1
              }
          }
          else if (dkey == true) {  // 오른쪽 키가 눌렸을 때 
              if (golemX < backgroundX-golemsizeX) { //멥판정
            	  golemcanleft=0;
            	  for (var i = 0; i < enemyList.length; i++) {  // 좌충돌판정
                      var tar = enemyList[i];
                      
            	  	  if(golemX < tar.x + black0sizeX && golemX > tar.x -golemsizeX-golemSpeed && golemY < tar.y + black0sizeY && golemY > tar.y -golemsizeY){
            	  		golemcanleft+=1
            	  	
            	  		golemX = tar.x -golemsizeX;//이동가능한 최대 위치로 이동;
            	  	  }
            	  }
            	  if(golemcanleft==0){
            		  golemX += golemSpeed;
            	  }     	 
              }else{
            	  golemcanleft+=1
                  
              }
          }
          
     }
     

/*------------------------------------큐브 연산----------------------------------------------------------------*/
      function movecube(){//큐브연산
    	  for (var i = 0; i < cubeList.length; i++) {
              var tmp1 = cubeList[i];
              
              //족제비 좌우 충돌
              	if(myairX < tmp1.x + cubesizeX && myairX > tmp1.x - (my0sizeX) && myairY < tmp1.y + cubesizeY && myairY > tmp1.y - my0sizeY+5){
              		//5정도는 떨어트려놔야 위쪽에 있을때 반응안함
          			if(myairX < tmp1.x + cubesizeX/2-(my0sizeX)/2){
          				myairX=tmp1.x - (my0sizeX)//큐브이동에 따라 움직임
          				
          			}
          			else{
          				myairX=tmp1.x + cubesizeX//이동가능한 최대 위치로 이동;
          			}
          			

          		}
              //족제비 상 충돌
              	if(myairX < tmp1.x + cubesizeX && myairX > tmp1.x - (my0sizeX) && myairY < tmp1.y + 5 && myairY > tmp1.y -my0sizeY-myspeedY){
              		myairY=tmp1.y-my0sizeY;//이동가능한 최대 위치로 이동;
      				myspeedY=0;
      				canjump=1
      				myairX+=tmp1.speedx;//큐브와같이이동
              	}
              
              //골램 가로 충돌
              if(golemX < tmp1.x + cubesizeX && golemX > tmp1.x - (golemsizeX) && golemY < tmp1.y + cubesizeY && golemY > tmp1.y - golemsizeY){
            	//족제비 가로 충돌
				  
            	  if(golemX < tmp1.x + cubesizeX/2-(golemsizeX)/2){//중심위치 비교
            		 
            		  tmp1.speedx=golemSpeed/2;//우
            	
            	      
            	  }else{
            		  tmp1.speedx=-golemSpeed/2;//좌
            	
            		  
            	  }
            	  
            	  golemX-=tmp1.speedx;//속도 감소효과
            	  if(golemup==true){
            		  myairX-=tmp1.speedx;//속도 감소효과 안 넣어주면 따로 이동함
            	  }
            	  tmp1.x+=tmp1.speedx;//이동
            	  
            	  
            	  
              }else{
            	  tmp1.speedx=0;//정지
            	  
              }
            	  
              
          }
      }