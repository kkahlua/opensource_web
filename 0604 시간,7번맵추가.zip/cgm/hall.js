var hall = new Image();
hall.src = "image/testobj.png";//반투과 플렛폼
var hallList = [];

function makeground(){
	for(var i = 0; i < 30; i++){
		makeEnemy(50*i,750);
	}
}

function makeground5(){
	for(var i = 0; i < 30; i++){
		if(i == 4 || i == 5 || i == 6){
			makehall(50*i,750);
			continue;
		}
		makeEnemy(50*i,750);
	}
}

function makehall(){
    var obj = {};
    // 위치 설정
    obj.x = 0;
    obj.y = 0;
  
    hallList.push(obj);
}

function drawhall(){
    for (var i = 0; i < hallList.length; i++) {
    	context.drawImage(hall, tmp.x, tmp.y, black0sizeX, black0sizeY);
    }
}

function checkhall(){
	if(myairY > 850){
		myairY = -50;
	}
	
	if(golemY > 850){
		golemY = -50;
	}
}