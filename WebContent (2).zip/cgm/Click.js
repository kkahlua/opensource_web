canvas.style.background = "#a6e1f5";

		canvas.addEventListener('click', (event) =>{
      	const rect = canvas.getBoundingClientRect();
      	const x = event.clientX - rect.left;
      	const y = event.clientY - rect.top;
      	if(start_do == 0)
      		circle.clickCircle(x,y);
      	if(home_do == 1)
      		home1.clickHome(x,y);
      	if(homebar_do == 1){
      		musicof.clickMusic(x,y);
      		soundof.clickSound(x,y);
      		home_bar.clickHomebar(x,y);
      	}
      	if(map_do == 1){
      		mapdr.clickMap1(x,y);
      		mapdr.clickMap2(x,y);
      		mapdr.clickMap3(x,y);
      		mapdr.clickMap4(x,y);
      		
      	}
      	console.log('x: ' + x + ' y: ' + y);
      });