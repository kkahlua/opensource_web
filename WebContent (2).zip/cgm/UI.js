
      var start_do = 0; // 시작했는지 안했는지
      var home_do = 0; // 홈을 눌렀는지 안했는지
      var homebar_do = 0; // 홈 바를 눌렀는지 안했는지
      var music_do = 1; // 배경음악이 들리는가
      var sound_do = 1; // 효과음 들리는가
      var map_do = 0; // 맵이 열렸는지
      
      var home = new Image(); // 홈 이미지
      home.src = "image/home.png";
      
      var play = new Image(); // 플레이 이미지
      play.src = "image/play.png";
      
      var homebar = new Image(); // 홈_바 이미지
      homebar.src = "image/home_bar.png";
      
      var menu = new Image(); // 메뉴 이미지
      menu.src = "image/menu.png";
    	
      // 시작 버튼
		class Circle{
			draw(context){
				context.drawImage(play, 650,500, 200, 100); // 그리기
			}
			
			clickCircle(xmouse,ymouse){
				if(xmouse > 650 && xmouse < 850 && ymouse > 500 && ymouse < 600){
					console.log('clicked play');
					start_do = 1;
					home_do = 1;
					map_do = 1;
// playAudio();
					GoMap();
					return true;
				}else{
					return false;
				}
			}
		}
		
		// 홈 버튼
		class Home1{
			draw(context){
				context.drawImage(home, 0, 0, 50, 50); // 그리기
			}

			clickHome(xmouse,ymouse){
				if(xmouse > 0 && xmouse < 50 && ymouse > 0 && ymouse < 50){
					console.log('clicked home');
					home_do = 1;
					if(homebar_do == 1)
						homebar_do = 0;
					else
						homebar_do = 1;
					return true;
				}else{
					return false;
				}
			}
		}
		
		// 홈바 버튼
		class Home_bar{
			draw(context){
				context.drawImage(homebar, 350, 50, 800, 700); // 그리기
				musicof.draw(context);
				soundof.draw(context);
				context.drawImage(menu, 650,200,200,100);
			}
			
			clickHomebar(xmouse,ymouse){
				if(xmouse > 650 && xmouse < 850 && ymouse > 200 && ymouse < 300){
					console.log('clicked menu');
					home_do = 0;
					map_do = 1;
					homebar_do = 0;
					GoMap();
					return true;
				}else{
					return false;
				}
			}
		}
		// 배경음악온오프 버튼
		class Musicof{
			draw(context){
				if(music_do == 1)
					context.drawImage(musicOn, 600, 450, 100, 100); // 그리기
				else
					context.drawImage(musicOff, 600, 450, 100, 100); // 그리기
			}
			
			clickMusic(xmouse,ymouse){
				if(xmouse > 600 && xmouse < 700 && ymouse > 450 && ymouse < 550){
					console.log('clicked home');
					if(music_do == 1){
						stopAudio();
						music_do = 0;
					}else{
						playAudio();
						music_do = 1;
					}
					return true;
				}else{
					return false;
				}
			}
		}
		// 효과음온오프 버튼
		class Soundof{
			draw(context){
				if(sound_do == 1)
					context.drawImage(soundOn, 800, 450, 100, 100); // 그리기
				else
					context.drawImage(soundOff, 800, 450, 100, 100); // 그리기
			}
			
			clickSound(xmouse,ymouse){
				if(xmouse > 800 && xmouse < 900 && ymouse > 450 && ymouse < 550){
					console.log('clicked home');
					if(sound_do == 1)
						sound_do = 0;
					else
						sound_do = 1;
					return true;
				}else{
					return false;
				}
			}
		}
			
      
  		let circle = new Circle();
  		let home1 = new Home1();
  		let home_bar = new Home_bar();
		let musicof = new Musicof();
		let soundof = new Soundof();