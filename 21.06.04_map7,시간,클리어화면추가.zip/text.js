var timeCount=0;
var sec=0;
var finish_sec=0;
var timer_on=true;
function timer() {
  if(timer_on==true)
  {

    if(map_count!=8)//테스트하려면 8을 따른숫자로
    {
      timeCount++;
     if(timeCount%100==0) sec++;
     $("#timed").html("Time : "+sec);
    }
     
   if(map_count==8)
   {
    timeCount++;
    if(timeCount%100==0) finish_sec++;
    $("#finish").html("You win<br />총 걸린시간 : " + sec);
    if(finish_sec>10)
      $("#finish").hide();
   }
  }

}
      