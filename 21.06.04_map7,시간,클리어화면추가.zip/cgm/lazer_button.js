var missilebutton = new Image();
missilebutton.src = "image/missilebutton.png";
var missilebuttonList = [];

var true_misslebutton = 0;

var button_check = false;

function makemissilebutton(objx, objy) {// 버튼업
	var obj = {};
	// 위치 설정
	obj.x = objx;
	obj.y = objy;
	obj.check = false;

	missilebuttonList.push(obj);
}

function drawmissilebutton() {// 미사일 버튼
	for (var i = 0; i < missilebuttonList.length; i++) {
		var tmp = missilebuttonList[i];
		for (var j = 0; j < missileList.length; j++) {
			var tmp2 = missileList[j];// 레이저
			if (tmp2.x < tmp.x + buttonsizeX && tmp2.x > tmp.x
					&& tmp2.y < tmp.y + buttonsizeX && tmp2.y > tmp.y && tmp.check == false) {// 레이저와
																		// 충돌시
																		// 작동
				tmp.check = true;
				checkmissilebutton();
			}
		}
		context.drawImage(enemy2, tmp.x, tmp.y, buttonsizeX, buttonsizeX);
		context.drawImage(missilebutton, tmp.x - 25, tmp.y, buttonimagesizeX,
				buttonimagesizeY);
		if (tmp.check)
			context.drawImage(buttonL, tmp.x - 25, tmp.y, buttonimagesizeX,
					buttonimagesizeY);
	}
}

function checkmissilebutton(){
	switch (map_count){
	case 4:
		if(true_misslebutton < 5)
			true_misslebutton++;
		if(true_misslebutton == 5){
			button_check = true;
		}
		break;
	default:
		break;
	}
}