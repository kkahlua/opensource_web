var keypress = false;   //맵이동버튼 
var check = true;